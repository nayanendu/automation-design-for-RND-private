__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import xml.etree.ElementTree as ET
import commands
import pexpect
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
import base64
import csv,tabulate
import re
import locale
import traceback
from decimal import *
from dominate.tags import *
from types import NoneType
import json
from subprocess import Popen, PIPE
import tempfile
import zipfile
import shutil
from dateutil.relativedelta import relativedelta
from mysqldatasource import *
from podiumutils import *
from scriptcreation import *
from qctracker import *
##parent_directory = os.path.dirname(os.path.realpath(__file__))

os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")


REPLY_TO = 'dwh-no-reply@astellaswatcher.com'
password = "YXN0ZWxsYXN3YXRjaGVyQGV4bA=="
parent_directory = os.getcwd()
hdfs_put_directory = '/user/npradhan/adhoc_monthly_loads/'
source_with_str={'truven_lookups':'_lookups'}
date_in_loaddirectory = ['ims_pharmetrics_claims_omop','mdv','jmdc','jmdc_japanese','meditrend','premier','cprd']

'''import pandas as pd
csv_input = pd.read_csv('input.csv')
csv_input['Berries'] = csv_input['Name']
csv_input.to_csv('output.csv', index=False)'''


def kinit():
	print "Inside Kinit"
	try:
		##os.system('echo "7<F4rr38wBFD" | kinit npradhan')
		os.system('echo "Welcome@123" | kinit podium')
		child = pexpect.spawn('kinit')
		child.expect('Password for npradhan@ASTELLASRWI.US:')
		child.sendline('7<F4rr38wBFD')
	except Exception as e:
		print e

def manual_sources(source,s3,filedate):
	print "Inside manual_source"
	if source == 'sha_urology_prescriber' :
		file_list = ['astoab_prescriber_sob_national_summary_','astoab_prescriber_sob_national_switch_from_summary_']
		os.system("rm -f %s/manual/*"%parent_directory)
		os.system("/usr/local/bin/aws s3 sync s3://%s%s %smanual/."%(s3,filedate,parent_directory))
		for i in file_list:
			file2move = '%smanual/%s%s'%(parent_directory,i,filedate)
			os.system("xlsx2csv '%s.xlsx' '%s.csv'"%(file2move,file2move))
			if 'national_summary_' in file2move:
				os.system('cat %s.csv | sed "s/$/,/g" > %s.cav.bkp'%(file2move,file2move))
				os.system('rm -f %s.csv'%file2move)
				os.system('mv %s.cav.bkp %s.csv'%(file2move,file2move))
			os.system('/usr/local/bin/aws s3 cp %s.csv s3://%s%s/'%(file2move,s3,filedate))


def importExport(listOfSourceEntityWithIDs, oldSourceName, newSourceName, zipFileName):
        for sourceName in listOfSourceEntityWithIDs:
                        if oldSourceName in sourceName.split(':'):
                                sourceID = sourceName.split(':')[1].rstrip('\n')
        os.system("curl -s --request GET http://10.208.2.65:8675/podium/metadataExport/v1/sources/"+sourceID+" --cookie cookies.txt --output "+zipFileName)
        updateZip(zipFileName, oldSourceName, newSourceName)
        os.system('java -cp PodiumAPIClient.jar com.podiumdata.tools.apiclient.ImportEntity podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium '+zipFileName+">/dev/null 2>&1")


def validate(date_text,date_format,folder_len):
	if len(date_text) == int(folder_len):
		try:
			datetime.strptime(date_text, '%s'%date_format)
			return True
		except ValueError:
			return False
	

def awscheck(s3,last_loaded,folderformat,file_name):
	print "Inside awscheck"
	final_folder_list=[]
	result = commands.getstatusoutput('/usr/local/bin/aws s3 ls %s'%(s3))
	for i in result:
		if isinstance(i,str) and  'PRE' in str(i):
			j=i.replace(' ','')
			j=j.split('/\n')
			for folder in j:
				if 'PRE' in folder:
					val = folder.replace('PRE','').replace('/','').replace('_','')
					val = re.sub('[^0-9]+', '', val)
					boolean=validate(val,folderformat,len(last_loaded))
					if boolean is True:
						final_folder_list.append(val)
	print final_folder_list
	if len(final_folder_list) > 0 :
		final_folder = final_folder_list[-1]
	else:
		final_folder = '2013-01-01'
	result = commands.getstatusoutput('/usr/local/bin/aws s3 ls %s%s/%s'%(s3,final_folder,file_name))[1]
	if final_folder > last_loaded:
		if file_name == 'NA':
			return final_folder
		else:
			if file_name in result:
				return final_folder
			else:
				return last_loaded		
			
	else:
		return last_loaded

def awscheck_sourcetype_two(s3,last_loaded,folderformat,filename):
	print "Inside awscheck sourcetype two"
        result = commands.getstatusoutput('/usr/local/bin/aws s3 ls %s'%(s3))
	result = result[1].split('\n')
	source_filename,latest_date = 0,0
	for i in result:
		j = i.split(' ')
		counter = 0
		file_criteria = filename.split('|')
		for p in file_criteria:
			if p in j[len(j)-1]:
				counter = counter + 1
		if len(file_criteria) == counter:
			source_filename = j[len(j) -1]
			latest_date = j[0]
	##d1 = datetime.strptime(latest_date,'%Y-%m-%d')
	##d2 = datetime.strptime(last_loaded,'%Y-%m-%d')
	if latest_date > last_loaded:
		return latest_date,source_filename
	else:
		return last_loaded,source_filename	
	

def hdfsloadcheck(offset_date,source_name,hdfsloaddirectory):
        load_date_check = offset_date.strftime('%Y%m%d')
        cmd = """hadoop fs -ls -R %s | grep "^d" | grep "%s" | awk '{print $8}' | awk -F'/' '!length($7)' """%(hdfsloaddirectory,load_date_check)
	proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
	(out, err) = proc.communicate()
	out=out.split('\n')
        num_lines = len(out)
        return num_lines
	


def s3updatedat(s3,final_folder):
	now = datetime.now()
	cmd = """aws s3 ls --recursive %s%s/ | sort | tail -n 1 | awk '{print $1,$2}'"""%(s3,final_folder)
	execute = Popen(cmd, shell=True, stdout=PIPE)
	output = execute.stdout.read()
	output = output.replace('\n','')
	cmp_output = datetime.strptime(output,'%Y-%m-%d %H:%M:%S')
	##min_diff = (now - cmp_output).days * 24 * 60
	import time
	d1_ts = time.mktime(cmp_output.timetuple())
	d2_ts = time.mktime(now.timetuple())
	min_diff = int(d2_ts-d1_ts) / 60
	if int(min_diff) >= 1 :
		process = True
	else :
		process = False
	return process,output

def offset_calculator(final_folder,folderformat,load_type):
	now = datetime.now()
	if load_type == 'quarterly':
		quarter = int(datetime.strptime(final_folder,'%s'%folderformat).month)
		offset_day = datetime.strptime(final_folder,'%s'%folderformat)
		two_mon_rel = relativedelta(months= int(quarter) * 2)
		offset_date = offset_day+two_mon_rel
		offset = (now - offset_date).days
	else:
		offset_date = datetime.strptime(final_folder,'%s'%folderformat)
		offset = (now - offset_date).days
	return offset_date,offset

if __name__ == "__main__":
	kinit()
		
	query = """select source_id,source_name,load_type,s3location,last_loaded,load_date_check,folder_format,hdfsdatadir,subject_area,execution_flow,fullrefresh,status_flag,file_name,execution_hour,manual_inter,mailto  from source"""
	data = execute_fetch_data(query)
	
	for source in data:
		source_id,source_name,load_type,s3,last_loaded,load_date_check,folderformat,hdfsdatadir,subject_area,execution_flow,fullrefresh,flag,file_name,execution_hour,manual_inter,mailto = source[0],source[1],source[2],source[3],source[4],source[5],source[6],source[7],source[8],source[9],source[10],source[11],source[12],source[13],source[14],source[15]
		print "####################### ",source_name
		if int(flag) == 0 :
			print "Insdie phase 0"
			if file_name == 'NA':
				final_folder = awscheck(s3,last_loaded,folderformat,file_name)
			else:
				final_folder = awscheck_sourcetype_two(s3,last_loaded,folderformat,file_name)
			print source_name,final_folder
			##final_folder = '20180201'
			if final_folder == last_loaded:
				pass
			else:
				print "Inside processing phase 0"
				process,updated_at = s3updatedat(s3,final_folder)
				process = True
				if process == True:
					if fullrefresh != 'NA' :
						source_name_old = source_name+'_'+last_loaded
						source_name_new = source_name+'_'+final_folder
						store_entities_to_db(source_name,source_id,source_name_old)
						offset_date,offset = offset_calculator(final_folder,folderformat,load_type)
						create_sh(source_name,offset,final_folder,source_name_new)
						executequery("""update source set load_date_check='%s',status_flag=1,received_at='%s' where source_id=%s"""%(final_folder,updated_at,source_id))
						executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Found new data set.Initiating data loading process','%s')"""%(source_id,source_name_new,final_folder))
						create_sa_sh(source_name)
					else:
						store_entities_to_db(source_name,source_id)
						if manual_inter != 'NA' :
							manual_sources(source_name,s3,final_folder)
						offset_date,offset = offset_calculator(final_folder,folderformat,load_type)
						ifexists_data = hdfsloadcheck(offset_date,source_name,hdfsdatadir)
						ifexists_data = 0
						if ifexists_data > 0 :
							print "Data already loaded for ",final_folder
							executequery("""update source set load_date_check='%s',status_flag=2,received_at='%s' where source_id=%s"""%(final_folder,updated_at,source_id))
							executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Data already loaded using other mechanism','%s')"""%(source_id,source_name,final_folder))
						else:
							print "Inside phase 0 else"
							create_sh(source_name,offset,final_folder)
							executequery("""update source set load_date_check='%s',status_flag=1,received_at='%s' where source_id=%s"""%(final_folder,updated_at,source_id))
							executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Found new data set.Initiating data loading process','%s')"""%(source_id,source_name,final_folder))
							create_sa_sh(source_name)

		elif int(flag) == 1 :
			print "Inside Phase 1"
			status_output = execute_fetch_data("""SELECT (EXISTS (SELECT 1 FROM execution_logs WHERE folder='%s' and source_id=%s and phase='Initiated Data Loading'))"""%(load_date_check,source_id)) 
			status_output = status_output[0][0]
			print status_output
			#loadcheck = hdfsloadcheck(load_date_check,source_name,hdfsloaddirectory,folderformat)
			if int(status_output) == 0 :
				print "Inside phase 2 execution"
				#if datetime.now().hour in range(9,16):
				#	pass
				#else:
				#os.system("""nohup python scriptexecutor.py %s '%s' '%s' > execution_logs/%s.txt 2>&1 &"""%(source_id,source_name,load_date_check,source_name.replace('.','_')))
				print "python scriptexecutor.py %s '%s' '%s'"%(source_id,source_name,load_date_check)
				os.system("""python scriptexecutor.py %s '%s' '%s' > execution_logs/%s.txt"""%(source_id,source_name,load_date_check,source_name.replace('.','_')))

				
		elif int(flag) == 2 :
			print "Inside phase 2",source_name
			log_status = getLogs(source_name,load_date_check,folderformat)
			if log_status == True:
				executequery("""update source set last_loaded='%s',status_flag=0 where source_id=%s"""%(load_date_check,source_id))
			##qc_status = final_qc(source_name)
                        ##if qc_status == True:
                                ##executequery("""update source set last_loaded='%s',status_flag=0 where source_id=%s"""%(load_date_check,source_id))

		elif int(flag) == 4 :
			print "Inside phase 3 - Fixed Scripts",source_name	
			final_folder = awscheck(s3,last_loaded,folderformat,file_name)
			if final_folder == last_loaded:
                                pass
                        else:
                                print "Inside processing phase 0 - Fixed Scripts"
                                process,updated_at = s3updatedat(s3,final_folder)
                                process = True
                                if process == True:
					store_entities_to_db(source_name,source_id)
                                        offset_date,offset = offset_calculator(final_folder,folderformat,load_type)
                                        create_sh(source_name,offset,final_folder)
                                        executequery("""update source set load_date_check='%s',status_flag=1,received_at='%s' where source_id=%s"""%(final_folder,updated_at,source_id))
                                        executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Found new data set.Initiating data loading process','%s')"""%(source_id,source_name,final_folder))
                                        ##create_sa_sh(source_name)
					os.system("""nohup sh workflows/%s.sh > execution_logs/%s.txt 2>&1 &"""%(workflow,workflow))	

		
	'''if os.path.isfile(tobeloaded_file):
		f = open(tobeloaded_file,'r')
		raw_data = []
		for i in f:
			raw_data.append(tuple(i.replace('\n','').split(',')))
		raw_data = tuple(raw_data)
		html = generate_html(raw_data, 'Source,FolderToBeLoaded,Status', 'StatusReport')
		SendMail('PFA',html)
		print "Inside Final Mail"	
		##send_mail_tabulate(tobeloaded_file)

	send_mail('npradhan1989@gmail.com','Log file for %s execution'%filehour,'Please find the atatched log file',logfile)'''



