__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
from mysqldatasource import *


if __name__ == "__main__":
	print "Inside Main data loading"
	source_id = sys.argv[1]
	source_name = sys.argv[2]
	folder = sys.argv[3]
	if '.' in source_name:
		scriptname = source_name.replace('.','_')
	else:
		scriptname = source_name
	query = """SELECT execution_flow FROM source WHERE source_name = '%s';"""%source_name
        data = execute_fetch_data(query)
	data = data[0][0]
	print data
	executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Initiated Data Loading','%s')"""%(source_id,source_name,folder))
	if data == 'NA':
		os.system('bash scripts/%s.sh'%scriptname)
	else:
		if '->' in data:
			scripts = data.split('->')
		else:
			scripts = data.split(',')
		for script_to_execute in scripts:
			if '.sh' in script_to_execute:
				os.system('bash scripts/%s'%script_to_execute)
			elif '.hql' in script_to_execute:
				os.system('beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/%s'%script_to_execute)
			elif '.pig' in script_to_execute:
				os.system('pig -f scripts/%s'%script_to_execute)
			else :
				pass
	executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Completed Data Loading','%s')"""%(source_id,source_name,folder))
	executequery("""update source set status_flag=2 where source_id=%s"""%source_id)

