__author__ = 'Nayanendu'

import os
import sys
from datetime import datetime,timedelta
import MySQLdb as db



def dbconnection():
	handle = db.connect(host='rwi-mysql.cpeiqr9rlz03.us-east-1.rds.amazonaws.com', port=3306, user='automation',passwd='automation123', db='automation_framework')	
	cursor = handle.cursor()
	return handle,cursor


def closedbconnection(handle):
	handle.close()


def executequery(query):
	handle,cursor = dbconnection()
	cursor.execute(query)
        handle.commit()
	closedbconnection(handle)


def execute_fetch_data(query):
        handle,cursor = dbconnection()
        cursor.execute(query)
	data = cursor.fetchall()
        closedbconnection(handle)
	return data

def insertdata(cursor,table,column,value):
	query = """insert into %s(%s) values(%s)"""%(table,column,value)
	cursor.execute(query)
	cursor.commit()


def updatedata(cursor,table,column,value,condition):
	query = """update %s set %s=%s where %s"""%(table,column,value,condition)
	cursor.execute(query)
        cursor.commit()

def exportdetailedlogs(query,filename):
        handle,cursor = dbconnection()
        cursor.execute(query)
	os.system('rm -f hive_data_validation/%s.csv'%filename)
	f = open('hive_data_validation/%s.csv'%(filename),'a+')
	f.write('source_name,entity_name,deliverydate,status,info,folderdate,start_time,end_time,good_records,bad_records,ugly_records,hdfs_partition,hive_data_validation,col_shifting,updated_at\n')
	for i in cursor.fetchall():
		##source_name,entity_name,deliverydate,status,info,folderdate,start_time,end_time,good_records,bad_records,ugly_records
		f.write('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n'%(i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10],i[11],i[12],i[13],i[14]))
	f.close()
        handle.commit()
        closedbconnection(handle)

#exportdetailedlogs("""SELECT * FROM detailed_logs WHERE source_name='ims_ambulatory_emr' AND deliverydate='20171201';""",'ims_ambulatory_emr')
#exportdetailedlogs("""SELECT * FROM detailed_logs WHERE source_name='sha_antifungal_prescriber_idv' AND deliverydate='20180316';""",'sha_antifungal_prescriber_idv')
#exportdetailedlogs("""SELECT * FROM detailed_logs WHERE source_name='sha_immunology_prescriber_idv' AND deliverydate='20180316';""",'sha_immunology_prescriber_idv')


