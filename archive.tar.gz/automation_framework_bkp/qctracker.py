__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
import json
from mysqldatasource import *


def validate_fdfs_partition_and_hive_data(source,entity,partition):
        cmd = """hadoop fs -ls -R /data/receiving/%s/%s | grep "^d" | grep "%s" | awk '{print $8}' | awk -F'/' '!length($7)' """%(source,entity,partition)
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
        (out, err) = proc.communicate()
        out=out.split('\n')
        partition_cnt = len(out)
	os.system('''beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -e "select * from %s.%s where podium_delivery_date='%s' limit 5" > hive_data_validation/%s_%s_qc.txt'''%(source,entity,partition,source,entity))
	cmd = """wc -l hive_data_validation/%s_%s_qc.txt | awk '{print $1}'"""%(source,entity)
	proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
	(out, err) = proc.communicate()
	data_cnt = out
	return partition_cnt,data_cnt

	

	
def final_qc(sourceName,source_extra=None):
        os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
        query = """select count(1) from qc_logs where source_name='%s'"""%sourceName
        data = execute_fetch_data(query)
        qc_cnt = data[0][0]
	print qc_cnt
        if qc_cnt > 0 :
                query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%sourceName
                data = execute_fetch_data(query)
                data = data[0][0]
                entities = data.split(',')
                for entityID in entities:
                        failed_col = 0
                        eid = int(entityID) + 1
                        cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                        cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
                        cmdJSON = json.load(cmdPipe.stdout)
                        for col_prop in cmdJSON['subList']:
                                col_name = col_prop['name']
                                if ('dt' in col_name or '_date' in col_name or 'id' in col_name) and 'podium_delivery_date' not in col_name:
                                        query = """select min,max from qc_logs where source_name='%s' and entity_id=%s and column_name='%s'"""%(sourceName,entityID,col_name)
                                        data = execute_fetch_data(query)
                                        print data
                                        data = data[0]
                                        print data
                                        pre_min,pre_max = data[0],data[1]
                                        cur_min,cur_max = col_prop['minValue'],col_prop['maxValue']
                                        if pre_min == 'None' and pre_max == 'None':
                                                pass
                                        else:
                                                if len(cur_min) == len(pre_min) and len(cur_max) == len(pre_max):
                                                        print "Matching"
                                                else:
                                                        failed_col = failed_col + 1
                                entity_name = col_prop['parentEntityName']
                        print entity_name
                        if failed_col > 0 :
                                update_query = """update detailed_logs set col_shifting='FA' where source_name='%s' and entity_name='%s'"""%(sourceName,entity_name)
                        else:
                                update_query = """update detailed_logs set col_shifting='SU' where source_name='%s' and entity_name='%s'"""%(sourceName,entity_name)
                        executequery(update_query)
			if cmdJSON['subList'][0]['deliveryId'] <> None :
                                ext_info = cmdJSON['subList'][0]['deliveryId']
                                ext_info = ext_info.split('.')
                                partition_cnt,data_cnt = validate_fdfs_partition_and_hive_data(ext_info[0],ext_info[1],ext_info[2])
                                if partition_cnt > 0 :
                                        update_query = """update detailed_logs set hdfs_partition='SU' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
                                        print update_query
                                        executequery(update_query)
                                else:
                                        update_query = """update detailed_logs set hdfs_partition='FA' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
                                        executequery(update_query)
                                if data_cnt >= 5 :
                                        update_query = """update detailed_logs set hive_data_validation='SU' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
                                        executequery(update_query)
                                else:
                                        update_query = """update detailed_logs set hive_data_validation='FA' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
                                        executequery(update_query)


        else:
                query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%sourceName
                data = execute_fetch_data(query)
                data = data[0][0]
                print data
                entities = data.split(',')
                for entityID in entities:
                        eid = int(entityID) + 1
                        cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                        cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
                        cmdJSON = json.load(cmdPipe.stdout)
			
                        for col_prop in cmdJSON['subList']:
                                col_name = col_prop['name']
                                if ('dt' in col_name or '_date' in col_name or 'id' in col_name) and 'podium_delivery_date' not in col_name:
                                        cur_min,cur_max = col_prop['minValue'],col_prop['maxValue']
                                        insert_query = """replace into qc_logs(source_name,entity_id,column_name,min,max) values('%s',%s,'%s','%s','%s')"""%(sourceName,entityID,col_name,cur_min,cur_max)
                                        executequery(insert_query)
                                        #cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                                        #cmdP = Popen(cmd, shell=True, stdout=PIPE)
                                        #cmdJ = json.load(cmdP.stdout)
                                        #print cmdJ
                                        #sys.exit(1)
			if cmdJSON['subList'][0]['deliveryId'] <> None :
				ext_info = cmdJSON['subList'][0]['deliveryId']
				ext_info = ext_info.split('.')
				partition_cnt,data_cnt = validate_fdfs_partition_and_hive_data(ext_info[0],ext_info[1],ext_info[2])
				if partition_cnt > 0 :
					update_query = """update detailed_logs set hdfs_partition='SU' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
					print update_query
					executequery(update_query)
				else:
					update_query = """update detailed_logs set hdfs_partition='FA' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
					executequery(update_query)			
				if data_cnt >= 5 :
					update_query = """update detailed_logs set hive_data_validation='SU' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
					executequery(update_query)
                        	else:
                                	update_query = """update detailed_logs set hive_data_validation='FA' where source_name='%s' and entity_name='%s'"""%(ext_info[0],ext_info[1])
					executequery(update_query)
        return True



#partition_cnt,data_cnt = validate_fdfs_partition_and_hive_data('astellas_customer_master', 'prof_source_xref', '20180325100000')
#print partition_cnt,data_cnt
#final_qc('astellas_customer_master')


	
