#!/bin/sh

sh test_run1.sh
wait
sh test_run2.sh
