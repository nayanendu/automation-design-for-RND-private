__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import xml.etree.ElementTree as ET
import commands
import pexpect
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
import base64
import csv,tabulate
import re
import locale
import traceback
from decimal import *
from dominate.tags import *
from types import NoneType
import json
from subprocess import Popen, PIPE
import tempfile
import zipfile
import shutil
from dateutil.relativedelta import relativedelta
from mysqldatasource import *
from podiumutils import *
from mailer import *


if __name__ == "__main__":
        print "Inside Main data loading"
        source_name = sys.argv[1]
        load_date_check = sys.argv[2]
        folderformat = sys.argv[3]
	receiver = sys.argv[4]
	source_id = sys.argv[5]
        executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Initiated Data Loading','%s')"""%(source_id,source_name,load_date_check))
	log_status = getLogs(source_name,load_date_check,folderformat)
        if log_status == True:
		executequery("""update source set last_loaded='%s',status_flag=3 where source_id=%s"""%(load_date_check,source_id))
		query = """SELECT source_name,entity_name,deliverydate,STATUS,if(status='SUCCESS','SUCCESS',info) FROM detailed_logs WHERE source_name='%s' AND deliverydate='%s';"""%(source_name,load_date_check)
		raw_data = execute_fetch_data(query)
		'''raw_data = []
		for i in f:
			raw_data.append(tuple(i.replace('\n','').split(',')))
		raw_data = tuple(raw_data)'''
		html = generate_html(raw_data, 'Source,Entity,Deliverydate,Status,Info', 'StatusReport')
		SendMail('PFA',html,receiver,source_name)


