__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import xml.etree.ElementTree as ET
import commands
import pexpect
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
import base64
import csv,tabulate
import re
import locale
import traceback
from decimal import *
from dominate.tags import *
from types import NoneType
import json
from subprocess import Popen, PIPE
import tempfile
import zipfile
import shutil
from mysqldatasource import *
from podiumutils import *

REPLY_TO = 'astellas-no-reply@astellaswatcher.com'
password = "YXN0ZWxsYXN3YXRjaGVyQGV4bA=="
parent_directory = os.getcwd()


def generate_html(raw_data, columns, name = None):
        if not raw_data:
            sys.exit(0)
        TWOPLACES = Decimal(10) ** -2
        column_style = ['normal' for x in columns.split(',')]
        h = html()
        with h.add(body('Hi All, \r\n PFB the source load status: \r\n')).add(div(id='content')):
            with table(style='border:1px solid black;border-radius:10px;border-collapse:seperate;',border="0",cellpadding="0", cellspacing="0",width="400", id="bodyTable").add(tbody()):
                l1 = tr()
                d1 = td(align="center",valign="top")
                with d1:
                    with table(style='border-bottom:1px solid black',border="0",cellpadding="0", cellspacing="0", width="100%", id="headerTable").add(tbody()):
                        htr = tr()
                        htd = td(name, style="padding: 10px;font-size: 16px;", align="center",valign="top")
                    with table(style='border-bottom:1px solid black;border-collapse:collapse;',border="0",cellpadding="0",cellspacing="0",width="100%",id="contentTable").add(tbody()):
                        l = tr()
                        for column in columns.split(','):
                            col = column.split('|')
                            if len(col) > 1:
                                 d = th()
                                 s1 = span(str(col[0]))
                                 with s1:
                                    attr(style="float:left")
                                 d += s1
                                 s = span(str(col[1]))
                                 with s:
                                    attr(style="float:right")
                                 d += s
                            else:
                                d = th(str(column))
                            with d:
                                attr(style="background-color:#81BEF7;border-bottom:1px solid black;padding:10px;font-weight:bold")
                            #with d:
                            #    attr(style="background-color:#81BEF7;border-bottom:1px solid black;padding:10px;font-weight:bold")
                            l += d
                        for row in raw_data:
                            l = tr(style="color:#505050;font-family:Helvetica, Arial, sans-serif;font-size:14px;line-height:125%;")
                            for i, cell in enumerate(list(row)):
                                if type(cell) in (float, Decimal, int, long):
                                    d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip())
                                elif type(cell) == NoneType:
                                    d = td(str('NA'))
                                elif type(cell) == str:
                                    d = td(cell.decode( 'utf-8', 'ignore'))
                                elif type(cell) == unicode:
                                    cell_val = cell.split('|')
                                    if len(cell_val) > 1:
                                        d = td(locale.format( '%d', round(int(float(cell_val[0]))), grouping=True).encode('utf-8', 'replace').strip())
                                        #print cell
                                        #span_val = unicode(int(float(l1[1]))) + (u'\u2191' if int(float(l1[1])) > 0 else u'\u2193')
                                        #print span_val
                                        #print '*'*100
                                        s = span(unicode(abs(int(float(cell_val[1])))).encode('utf-8','replace').strip())
                                        if int(float(cell_val[1])) > 0:
                                            s += span((u'\u25b2').strip())
                                        elif int(float(cell_val[1])) < 0:
                                            s += span((u'\u25bc').strip())
                                        #else:
                                        #    s += span((u'\u25bc').strip())
                                        with s:
                                            if int(float(str(cell_val[1]))) > 0:
                                                attr(style="color:green;float:right")
                                            elif int(float(str(cell_val[1]))) < 0:
                                                attr(style="color:red;float:right")
                                            else:
                                                attr(style="float:right")
                                        d += s
                                    else:
                                        d = td(cell if type(cell) is unicode else str(cell))
                                else:
                                    d = td(cell if type(cell) is unicode else str(cell))
                                with d:
                                    if type(cell) in (float, Decimal, int, long):
                                        attr(style="text-align:right;padding:5px;padding-right:2px;border:1px solid black;font-weight:"+column_style[i]+";")
                                    else:
                                        attr(style="text-align:left;padding:5px;padding-right:2px;border:1px solid black;font-weight:"+column_style[i]+";")
                                #if type(cell) == float:
                                #   d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip(), style="text-align:right;padding:5px;border:1px solid black;")
                                #elif type(cell) == Decimal:
                                #    d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip(), style="text-align:right;padding:5px;border:1px solid black;")
                                    #d = td(str(cell.quantize(TWOPLACES)).encode('ascii', 'replace').strip())
                                #elif type(cell) == int or type(cell) == long:
                                #    d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip())


                                    #d = td(str(cell.quantize(TWOPLACES)).encode('ascii', 'replace').strip())
                                #elif type(cell) == NoneType:
                                #    d = td(str('NA'), style="text-align:left;padding:5px;border:1px solid black;")
                                #elif type(cell) == str:
                                #    d = td(cell.decode( 'utf-8', 'ignore'), style="text-align:left;padding:5px;border:1px solid black;")
                                #else:
                                #    d = td(cell if type(cell) is unicode else str(cell), style="text-align:left;padding:5px;border:1px solid black;")
                                l += d
                   # with table(border="0",cellpadding="0", cellspacing="0", width="100%", id="footerTable").add(tbody()):
                   #     ftr = tr()
                   #     ftd = td('Report generated at ' + datetime.strftime(datetime.now(), '%Y-%m:%d %H:%M:%S'), align="center",valign="top")
                l1 += d1
        return h


def SendMail(message,html_message,receiver,files = None,date = None):
                msg = MIMEMultipart('alternative')
                fromEmail = 'astellaswatcher@gmail.com'
                if date is None:
                        ##toEmail = 'nayanendu.pradhan@exlservice.com,rishi.srivastava@exlservice.com,neetu.kumari2@exlservice.com,lakshmi.marupeddi@exlservice.com,bikram.chopra@exlservice.com'
                        ##msg['To'] = 'nayanendu.pradhan@exlservice.com,rishi.srivastava@exlservice.com,neetu.kumari2@exlservice.com,lakshmi.marupeddi@exlservice.com,bikram.chopra@exlservice.com'
                        print "################################ Inside Load Mail 1"
                        toEmail = receiver
                        msg['To'] = receiver
                else:
                        print "################################ Inside Log Mail 2"
                        toEmail = receiver
                        msg['To'] = receiver
                        ##toEmail = 'nayanendu.pradhan@exlservice.com,Bikram.Chopra@exlservice.com,Lakshmi.Marupeddi@exlservice.com,Mayank.Bhawnani@exlservice.com,Neetu.Kumari2@exlservice.com,Rishi.Srivastava@exlservice.com,Udit.Rastogi@exlservice.com,kishore.papineni@astellas.com'
                        ##msg['To'] = 'nayanendu.pradhan@exlservice.com,Bikram.Chopra@exlservice.com,Lakshmi.Marupeddi@exlservice.com,Mayank.Bhawnani@exlservice.com,Neetu.Kumari2@exlservice.com,Rishi.Srivastava@exlservice.com,Udit.Rastogi@exlservice.com,kishore.papineni@astellas.com'
                msg['Subject'] = 'Astellas Data Loading Status' + ' ' + (date if date is not None else '')
                bcc = ['npradhan1989@gmail.com']
                text = message
                html = html_message
                for body_charset in 'US-ASCII', 'ISO-8859-1', 'UTF-8':
                        try:
                                unicode(text).encode(body_charset)
                                unicode(html).encode(body_charset)
                        except UnicodeError:
                                pass
                        else:
                                break
                part1 = MIMEText(unicode(text).encode(body_charset), 'plain', 'utf-8')
                msg.attach(part1)
                if not (html_message==""):
                        part2 = MIMEText(unicode(html).encode(body_charset), 'html', 'utf-8')
                        msg.attach(part2)
		if files is not None:
			files = files.split(',')
		for f in files or []:
			with open(f, "rb") as fil:
				part = MIMEApplication(
                                	fil.read(),
                                	Name=basename(f)
	                        )
				part['Content-Disposition'] = 'attachment; filename="%s"' % basename(f)
				msg.attach(part)
                s = smtplib.SMTP('smtp.gmail.com:587')
                s.ehlo()
                s.starttls()
                s.login("astellaswatcher@gmail.com", "%s"%(base64.b64decode(password)))
                msg.add_header('reply-to',REPLY_TO)
		print toEmail
                s.sendmail(fromEmail, toEmail.split(',')+bcc, msg.as_string())
                s.quit()



query = """SELECT source_name,entity_name,deliverydate,status FROM detailed_logs WHERE source_name = 'ims_ambulatory_emr' and deliverydate='20171201';"""
raw_data = execute_fetch_data(query)
html = generate_html(raw_data, 'Source,Entity,Deliverydate,Status', 'StatusReport')
#SendMail('PFA',html,source)
SendMail('PFA',html,'TeamAstellas@exlservice.com','hive_data_validation/ims_ambulatory_emr.csv',date = None)

















