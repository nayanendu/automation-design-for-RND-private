__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
from mysqldatasource import *


if __name__ == "__main__":
	print "Inside Main data loading"
	source_id = sys.argv[1]
	source_name = sys.argv[2]
	folder = sys.argv[3]
	if '.' in source_name:
		scriptname = source_name.replace('.','_').replace(' ','')
	else:
		scriptname = source_name.replace(' ','')
	query = """SELECT execution_flow FROM source WHERE source_name = '%s';"""%source_name
        data = execute_fetch_data(query)
	data = data[0][0]
	print data
	executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Initiated Data Loading','%s')"""%(source_id,source_name,folder))
	##f = open('workflows/%s_%s.sh'%(source_name,source_id),'a+')
	
	if data == 'NA':
		os.system('rm -f workflows/%s_%s.sh'%(source_name,source_id))
		f = open('workflows/%s_%s.sh'%(source_name,source_id),'a+')
		f.write('#!/bin/sh\n')
		f.write('sh scripts/%s.sh'%scriptname)
		f.close()
		##os.system("""nohup sh workflows/%s_%s.sh > execution_logs/%s.txt 2>&1 &"""%(source_name,source_id,source_name))
	else:
		os.system('rm -f workflows/%s_%s.sh'%(source_name,source_id))
		f = open('workflows/%s_%s.sh'%(source_name,source_id),'a+')
		print "Inside Else"
		##f = open('workflows/%s_%s.sh'%(source_name,source_id),'a+')
		f.write('#!/bin/sh\n')
		if '->' in data:
			flow_list = data.split('->')
		for flows in flow_list:
			print "Inside For"
			if ',' in flows:
				print "Inside Flow"
				par_jobs = flows.split(',')
				sa_scripts=[]
				for script_to_execute in par_jobs:
					print script_to_execute
					if '.sh' in script_to_execute:
                                		f.write('sh scripts/%s &\n'%script_to_execute)
                        		elif '.hql' in script_to_execute or '.sql' in script_to_execute:
                                		f.write('beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/%s &\n'%script_to_execute)
						sa_scripts.append('%s'%script_to_execute.replace('.hql','.sh'))
                        		elif '.pig' in script_to_execute:
                                		f.write('pig -f scripts/%s &\n'%script_to_execute)
						sa_scripts.append('%s'%script_to_execute.replace('.pig','.sh'))
                        		else :
                                		pass
				f.write('wait\n')
				for sa_load_scripts in sa_scripts:
					f.write('sh scripts/%s &\n'%sa_load_scripts)
				f.write('wait\n')
			else:
					if '.sh' in flows:
                                                f.write('sh scripts/%s &\n'%flows)
                                        elif '.hql' in flows or '.sql' in flows:
                                                f.write('beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/%s &\n'%flows)
                                        elif '.pig' in flows:
                                                f.write('pig -f scripts/%s &\n'%flows)
                                        else :
                                                pass
					f.write('wait\n')
		f.close()
		print "File created"
		##os.system("""nohup sh workflows/%s_%s.sh > execution_logs/%s.txt 2>&1 &"""%(source_name,source_id,source_name))	
		'''else:
			scripts = data.split(',')
		for script_to_execute in scripts:
			if '.sh' in script_to_execute:
				os.system('bash scripts/%s'%script_to_execute)
			elif '.hql' in script_to_execute:
				os.system('beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/%s'%script_to_execute)
			elif '.pig' in script_to_execute:
				os.system('pig -f scripts/%s'%script_to_execute)
			else :
				pass'''
	executequery("""insert into execution_logs(source_id,name,status,phase,folder) values(%s,'%s','processing','Completed Workflow Creation and execution started','%s')"""%(source_id,source_name,folder))
	executequery("""update source set status_flag=2 where source_id=%s"""%source_id)

