#!/bin/sh
for i in 1 2 3 4 5
do
echo $i
sleep 5s
done
