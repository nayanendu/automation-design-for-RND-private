__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
import json
from mysqldatasource import *

def fetch_source_entity_info(sourceName,entityName = None):
	print "Inside fetch_source_entity_info",sourceName
	entity_info=list()
	os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
	cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/source/v1/getSourcesByCrit/?name='+sourceName+' --cookie cookies.txt'
	cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
	cmdJSON = json.load(cmdPipe.stdout)
	sid = cmdJSON[0]['id']
	print sid
	if entityName == None:
		cmd = """curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/%s --cookie cookies.txt"""%(sid)
		cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
		cmdJSON = json.load(cmdPipe.stdout)
		##print cmdJSON
		##sys.exit(1)
		for i in cmdJSON['subList']:
			print "#######################"
			if '_v1' not in i and '_v2' not in i and '_old' not in i and '_init' not in i and '_ugly' not in i:
				glob_pattern1=os.popen('java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient GetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium %s %s  src.file.glob'%(sourceName,i['name'])).read()
				glob_pattern=glob_pattern1[1:-2]
				temp = [i['name'],i['id'],glob_pattern]
				entity_info.append(temp)
	else:
		command2 = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/%s --cookie cookies.txt'%sid).read()
                sub_string = command2.split(entityName)[0]
                sub_string2 = sub_string[sub_string.rfind('id')+2:]
                eid = sub_string2[sub_string2.find(":")+1:sub_string2.find(",")].split()[0]
                glob_pattern1=os.popen('java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient GetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium '+sourceName+' '+entityName+' src.file.glob').read()
                glob_pattern=glob_pattern1[1:-2]
		temp = [entityName,eid,glob_pattern]
		entity_info.append(temp)
	return entity_info


def store_entities_to_db(source,source_id,entity=None):
	if '.' in source:
                act_source = source.split('.')[0]
                entity = source.split('.')[1]
	else:
		act_source = source
	query = """delete from entity where source_id=%s"""%source_id
	executequery(query)	
	entity_info = fetch_source_entity_info(act_source,entity)
	for i in entity_info : 
		val_to_replace = ''
		for j in i[2].split('/'):
			if '2016' in j or '2017' in j or '2018' in j :
				val_to_replace = j
		
		i[2] = i[2].replace('%s'%val_to_replace,'$folder_date')
		query = "insert into entity(source_name,entity_id,entity_name,source_id,glob) values('%s',%s,'%s',%s,'%s')"%(source,i[1],i[0],source_id,i[2])
		executequery(query)
	

def getLogs(source,load_date_check,folderformat,check_flag='ALL'):
	os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
	if check_flag == 'ALL':
		query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%source
	else:
		query = """SELECT group_conact(distinct entity_id) FROM detailed_logs WHERE source_name = '%s' and folderdate='%s';"""%(source,load_date_check)
        data = execute_fetch_data(query)
	data = data [0][0]
	entities = data.split(',')
        for entityID in entities:
		command='curl -s --request GET "http://10.208.2.65:8675/podium/entity/v1/loadLogs/'+entityID+'?count=1&sortAttr=loadTime" --cookie cookies.txt'
                logsPipe = Popen(command, shell=True, stdout=PIPE)
                logsJson = json.load(logsPipe.stdout)
                if len(load_date_check) < 6:
			load_date_check = datetime.strptime(load_date_check,'%s'%folderformat)
                        load_date_check = load_date_check.strftime('%s'%folderformat)
		##print "#################",len(logsJson['subList'])
		if len(logsJson['subList']) > 0 :
			if load_date_check in logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8]:
				if logsJson['subList'][0]['status'] == 'FAILED':
					executequery("""replace into detailed_logs(source_name,entity_name,deliverydate,status,info,folderdate) values('%s','%s','%s','FAILED','%s','%s')"""%(source,logsJson['subList'][0]['entityName'],logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8],logsJson['subList'][0]['infoMessage'].replace('\n',' ')[0:600],load_date_check))
				else:
					query = """insert ignore into detailed_logs(source_name,entity_name,deliverydate,status,info,folderdate,start_time,end_time,good_records,bad_records,ugly_records) values('%s','%s','%s','SUCCESS','%s','%s','%s','%s',%s,%s,%s)"""%(source,logsJson['subList'][0]['entityName'],logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8],logsJson['subList'][0]['infoMessage'].replace('\n',' ')[0:600],load_date_check,(datetime.fromtimestamp(logsJson['subList'][0]['startTime'] / 1e3)).strftime('%Y-%m-%d %H:%M:%S'),(datetime.fromtimestamp(logsJson['subList'][0]['endTime'] / 1e3)).strftime('%Y-%m-%d %H:%M:%S'),logsJson['subList'][0]['goodRecordCount'],logsJson['subList'][0]['badRecordCount'],logsJson['subList'][0]['uglyRecordCount'])
					executequery(query)


def get_qc_status(sourceName,source_extra=None):
	query = """select count(1) from qc_logs where source_name='%s'"""%sourceName
	data = execute_fetch_data(query)
	qc_cnt = data[0][0]

	if qc_cnt > 0 :
		query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%sourceName
		data = execute_fetch_data(query)
		entities = data.split(',')
		for entityID in entities:
			eid = int(entityID) + 1
			cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
			cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
			cmdJSON = json.load(cmdpipe.stdout)
			for col_prop in cmdJson['subList']:
				col_name = col_prop['name']
				if ('dt' in col_prop or '_date' in col_prop or 'id' in col_prop) and 'podium_delivery_date' not in col_prop:
					query = """select min,max from qc_logs where source_name='%s' and entity_id=%s and column_name='%s'"""%(sourceName,entityID,col_name)
					data = execute_fetch_data(query)
					data = data[0][0].split(',')
					pre_min,pre_max = data[0],data[1]
					cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
					cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
					
					
	else:
		query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%sourceName
                data = execute_fetch_data(query)
                entities = data.split(',')
                for entityID in entities:
                        eid = int(entityID) + 1
                        cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                        cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
                        cmdJSON = json.load(cmdpipe.stdout)
                        for col_prop in cmdJson['subList']:
                                col_name = col_prop['name']
                                if ('dt' in col_prop or '_date' in col_prop or 'id' in col_prop) and 'podium_delivery_date' not in col_prop:
                                        cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                                        cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
					print cmdPipe
					sys.exit(1)
					
		cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/source/v1/getSourcesByCrit/?name=%s --cookie cookies.txt'%sourceName
		cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
		cmdJSON = json.load(cmdPipe.stdout)
		sid = cmdJSON[0]['id']
	
		
                command1 = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/'+sid+' --cookie cookies.txt').read()
                count_of_entities=command1.count('{"id":')
                for k in range(1,count_of_entities+1):
                        command1_filter = command1.split('"name":"')[k]
                        i = command1_filter[:command1_filter.find(",")-1]
                        if '_history' not in i and '_str' not in i and '_old' not in i and '_init' not in i and '_ugly' not in i:
                                print i
                                command2 = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/'+sid+' --cookie cookies.txt').read()
                                sub_string = command2.split('name":"'+i+'"')[0]
                                sub_string2 = sub_string[sub_string.rfind('id')+2:]
                                eid1 = sub_string2[sub_string2.find(":")+1:sub_string2.find(",")].split()[0]
                                eid = int(eid1)+1
                                col_details = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/'+str(eid)+' --cookie cookies.txt').read()
                                columns = os.popen('hive -e "show columns from '+sourceName+'.'+i+'" ').read().split()
                                directory = directory_int+i+'.txt'
                                if not os.path.exists(directory):
                                        file = open(directory,"w+")
                                        for j in columns:
                                                if ('dt' in j or '_date' in j or 'id' in j) and 'podium_delivery_date' not in j:
                                                        latest_col_max1 = col_details.split('"name":"'+j+'"')[1]
                                                        latest_col_max = latest_col_max1[latest_col_max1.find("maxValue")+11:].split(",")[0]
                                                        latest_col_min1 = col_details.split('"name":"'+j+'"')[1]
                                                        latest_col_min = latest_col_min1[latest_col_min1.find("minValue")+11:].split(",")[0]
                                                        print(i+","+j+","+latest_col_max+","+latest_col_min)
                                                        file.write(j+","+latest_col_max+","+latest_col_min+"\n")
                                        file.close()
                                else:
                                        for j in columns:
                                                if ('dt' in j or '_date' in j or 'id' in j) and 'podium_delivery_date' not in j:
                                                        latest_col_max1 = col_details.split('"name":"'+j+'"')[1]
                                                        latest_col_max = latest_col_max1[latest_col_max1.find("maxValue")+11:].split(",")[0]
                                                        latest_col_min1 = col_details.split('"name":"'+j+'"')[1]
                                                        latest_col_min = latest_col_min1[latest_col_min1.find("minValue")+11:].split(",")[0]
                                                        file3 = open(directory,"r")
                                                        for line in file3.readlines():
                                                                if line.split(",")[0]==j:
                                                                        if len(line.split(",")[1])==len(latest_col_max) and (len(line.split(",")[2])-1)==len(latest_col_min):
                                                                                print("matching length")
                                                                        else:
                                                                                print("Not matching length")
                                                                                file2 = open(qc_file,"a")
                                                                                file2.write(i+"."+j+" column length is not same\n")
                                                                                file2.close()
                                                                                print(j+","+latest_col_max+","+latest_col_min+",0,"+line.split(",")[1]+","+line.split(",")[2]+"\n")
                                                                                print(str(len(line.split(",")[1]))+" "+str(len(latest_col_max))+" "+str(len(line.split(",")[2]))+" "+str(len(latest_col_min)))
                                                        file3.close()
                                        file1 = open(directory,"w")
                                        file1.close()
                                        for j in columns:
                                                if ('dt' in j or '_date' in j or 'id' in j) and 'podium_delivery_date' not in j:
                                                        latest_col_max1 = col_details.split('"name":"'+j+'"')[1]
                                                        latest_col_max = latest_col_max1[latest_col_max1.find("maxValue")+11:].split(",")[0]
                                                        latest_col_min1 = col_details.split('"name":"'+j+'"')[1]
                                                        latest_col_min = latest_col_min1[latest_col_min1.find("minValue")+11:].split(",")[0]
                                                        file1 = open(directory,"a")
                                                        file1.write(j+","+latest_col_max+","+latest_col_min+"\n")
                                                        file1.close()

        else:
                i=entityName
                command2 = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/'+sid+' --cookie cookies.txt').read()
                sub_string = command2.split('name":"'+i+'"')[0]
                sub_string2 = sub_string[sub_string.rfind('id')+2:]
                eid1 = sub_string2[sub_string2.find(":")+1:sub_string2.find(",")].split()[0]
                eid = int(eid1)+1
                col_details = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/'+str(eid)+' --cookie cookies.txt').read()
                columns = os.popen('hive -e "show columns from '+sourceName+'.'+i+'" ').read().split()
                #print(col_details)
                directory = directory_int+i+'.txt'
                if not os.path.exists(directory):
                        file = open(directory,"w+")
                        for j in columns:
                                if ('dt' in j or '_date' in j or 'id' in j) and 'podium_delivery_date' not in j:
                                        #print(col_details)
                                        latest_col_max1 = col_details.split('"name":"'+j+'"')[1]
                                        latest_col_max = latest_col_max1[latest_col_max1.find("maxValue")+11:].split(",")[0]
                                        latest_col_min1 = col_details.split('"name":"'+j+'"')[1]
                                        latest_col_min = latest_col_min1[latest_col_min1.find("minValue")+11:].split(",")[0]
                                        print(i+","+j+","+latest_col_max+","+latest_col_min)
                                        file.write(j+","+latest_col_max+","+latest_col_min+"\n")
                        file.close()
                else:
                        for j in columns:
                                print j
                                if ('dt' in j or '_date' in j or 'id' in j) and 'podium_delivery_date' not in j:
					print "Inside else j : ",j
                                        latest_col_max1 = col_details.split('"name":"'+j+'"')[1]
                                        latest_col_max = latest_col_max1[latest_col_max1.find("maxValue")+11:].split(",")[0]
                                        latest_col_min1 = col_details.split('"name":"'+j+'"')[1]
                                        latest_col_min = latest_col_min1[latest_col_min1.find("minValue")+11:].split(",")[0]
                                        file3 = open(directory,"r")
                                        for line in file3.readlines():
                                                if line.split(",")[0]==j:
                                                        if len(line.split(",")[1])==len(latest_col_max) and (len(line.split(",")[2])-1)==len(latest_col_min):
                                                                print("matching length")
                                                        else:
                                                                print("Not matching length")
                                                                file2 = open(qc_file,"a")
                                                                file2.write(i+"."+j+" column length is not same\n")
                                                                file2.close()
                                                                print(j+","+latest_col_max+","+latest_col_min+",0,"+line.split(",")[1]+","+line.split(",")[2]+"\n")
                                                                print(str(len(line.split(",")[1]))+" "+str(len(latest_col_max))+" "+str(len(line.split(",")[2]))+" "+str(len(latest_col_min)))
                                        file3.close()
                        #file2.close()
                        file1 = open(directory,"w")
                        file1.close()
                        for j in columns:
                                if ('dt' in j or '_date' in j or 'id' in j) and 'podium_delivery_date' not in j:
                                        latest_col_max1 = col_details.split('"name":"'+j+'"')[1]
                                        latest_col_max = latest_col_max1[latest_col_max1.find("maxValue")+11:].split(",")[0]
                                        latest_col_min1 = col_details.split('"name":"'+j+'"')[1]
                                        latest_col_min = latest_col_min1[latest_col_min1.find("minValue")+11:].split(",")[0]
                                        file1 = open(directory,"a")
                                        file1.write(j+","+latest_col_max+","+latest_col_min+"\n")
                                        file1.close()


        


##get_qc_status('astellas_customer_master','org_address_detail')

##store_entities_to_db('ims_urology_emr',32)
##store_entities_to_db('astellas_customer_master',98)

##getLogs('astellas_customer_master','20171015','%Y%m%d')
		
