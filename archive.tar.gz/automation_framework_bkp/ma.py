__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
import json
import xml.etree.ElementTree as ET
import commands
import pexpect
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
import base64
import re
import locale
import traceback
from decimal import *
from dominate.tags import *
from types import NoneType
from subprocess import Popen, PIPE
import tempfile
import zipfile
import shutil

REPLY_TO = 'dwh-no-reply@astellaswatcher.com'
password = "YXN0ZWxsYXN3YXRjaGVyQGV4bA=="
parent_directory = '/home/npradhan/workspace/adhoc_monthly_loads/'


def fetch_source_entity_info(sourceName):
        print "Inside fetch_source_entity_info",sourceName
        entity_info=list()
        os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
        cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/source/v1/getSourcesByCrit/?name='+sourceName+' --cookie cookies.txt'
        cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
        cmdJSON = json.load(cmdPipe.stdout)
        sid = cmdJSON[0]['id']
        print sid
	entityName = None
        if entityName == None:
                cmd = """curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/%s --cookie cookies.txt"""%(sid)
                cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
                cmdJSON = json.load(cmdPipe.stdout)
                for i in cmdJSON['subList']:
                        print "#######################"
                        if '_v1' not in i and '_v2' not in i and '_old' not in i and '_init' not in i and '_ugly' not in i:
                                glob_pattern1=os.popen('java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient GetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium %s %s  src.file.glob'%(sourceName,i['name'])).read()
                                glob_pattern=glob_pattern1[1:-2]
                                #temp = [i['name'],i['id'],glob_pattern]
                                entity_info.append(i['id'])
        return entity_info

def SendMail(message,html_message, date = None):
                msg = MIMEMultipart('alternative')
                fromEmail = 'astellaswatcher@gmail.com'
                if date is None:
                        toEmail = 'nayanendu.pradhan@exlservice.com,anusha.katikam.contractor@astellas.com'
                        msg['To'] = 'nayanendu.pradhan@exlservice.com,anusha.katikam.contractor@astellas.com'
                else:
                        toEmail = 'nayanendu.pradhan@exlservice.com,anusha.katikam.contractor@astellas.com'
                        msg['To'] = 'nayanendu.pradhan@exlservice.com,anusha.katikam.contractor@astellas.com'
                msg['Subject'] = 'Astellas Data Loading Status' + ' ' + (date if date is not None else '')
                bcc = ['npradhan1989@gmail.com']
                text = message
                html = html_message
                for body_charset in 'US-ASCII', 'ISO-8859-1', 'UTF-8':
                        try:
                                unicode(text).encode(body_charset)
                                unicode(html).encode(body_charset)
                        except UnicodeError:
                                pass
                        else:
                                break
                part1 = MIMEText(unicode(text).encode(body_charset), 'plain', 'utf-8')
                msg.attach(part1)
                if not (html_message==""):
                        part2 = MIMEText(unicode(html).encode(body_charset), 'html', 'utf-8')
                        msg.attach(part2)
                s = smtplib.SMTP('smtp.gmail.com:587')
                s.ehlo()
                s.starttls()
                s.login("astellaswatcher@gmail.com", "%s"%(base64.b64decode(password)))
                msg.add_header('reply-to',REPLY_TO)
                s.sendmail(fromEmail, toEmail.split(',')+bcc, msg.as_string())
                s.quit()

def generate_html(raw_data, columns, name = None):
        if not raw_data:
            sys.exit(0)
        TWOPLACES = Decimal(10) ** -2
        column_style = ['normal' for x in columns.split(',')]
        h = html()
        with h.add(body('Hi All, \r\n PFB the source load status: \r\n')).add(div(id='content')):
            with table(style='border:1px solid black;border-radius:10px;border-collapse:seperate;',border="0",cellpadding="0", cellspacing="0",width="400", id="bodyTable").add(tbody()):
                l1 = tr()
                d1 = td(align="center",valign="top")
                with d1:
                    with table(style='border-bottom:1px solid black',border="0",cellpadding="0", cellspacing="0", width="100%", id="headerTable").add(tbody()):
                        htr = tr()
                        htd = td(name, style="padding: 10px;font-size: 16px;", align="center",valign="top")
                    with table(style='border-bottom:1px solid black;border-collapse:collapse;',border="0",cellpadding="0",cellspacing="0",width="100%",id="contentTable").add(tbody()):
                        l = tr()
                        for column in columns.split(','):
                            col = column.split('|')
                            if len(col) > 1:
                                 d = th()
                                 s1 = span(str(col[0]))
                                 with s1:
                                    attr(style="float:left")
                                 d += s1
                                 s = span(str(col[1]))
                                 with s:
                                    attr(style="float:right")
                                 d += s
                            else:
                                d = th(str(column))
                            with d:
                                attr(style="background-color:#81BEF7;border-bottom:1px solid black;padding:10px;font-weight:bold")
                            #with d:
                            #    attr(style="background-color:#81BEF7;border-bottom:1px solid black;padding:10px;font-weight:bold")
                            l += d
                        for row in raw_data:
                            l = tr(style="color:#505050;font-family:Helvetica, Arial, sans-serif;font-size:14px;line-height:125%;")
                            for i, cell in enumerate(list(row)):
                                if type(cell) in (float, Decimal, int, long):
                                    d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip())
                                elif type(cell) == NoneType:
                                    d = td(str('NA'))
                                elif type(cell) == str:
                                    d = td(cell.decode( 'utf-8', 'ignore'))
                                elif type(cell) == unicode:
                                    cell_val = cell.split('|')
                                    if len(cell_val) > 1:
                                        d = td(locale.format( '%d', round(int(float(cell_val[0]))), grouping=True).encode('utf-8', 'replace').strip())
                                        #print cell
                                        #span_val = unicode(int(float(l1[1]))) + (u'\u2191' if int(float(l1[1])) > 0 else u'\u2193')
                                        #print span_val
                                        #print '*'*100
                                        s = span(unicode(abs(int(float(cell_val[1])))).encode('utf-8','replace').strip())
                                        if int(float(cell_val[1])) > 0:
                                            s += span((u'\u25b2').strip())
                                        elif int(float(cell_val[1])) < 0:
                                            s += span((u'\u25bc').strip())
                                        #else:
                                        #    s += span((u'\u25bc').strip())
                                        with s:
                                            if int(float(str(cell_val[1]))) > 0:
                                                attr(style="color:green;float:right")
                                            elif int(float(str(cell_val[1]))) < 0:
                                                attr(style="color:red;float:right")
                                            else:
                                                attr(style="float:right")
                                        d += s
                                    else:
                                        d = td(cell if type(cell) is unicode else str(cell))
                                else:
                                    d = td(cell if type(cell) is unicode else str(cell))
                                with d:
                                    if type(cell) in (float, Decimal, int, long):
                                        attr(style="text-align:right;padding:5px;padding-right:2px;border:1px solid black;font-weight:"+column_style[i]+";")
                                    else:
                                        attr(style="text-align:left;padding:5px;padding-right:2px;border:1px solid black;font-weight:"+column_style[i]+";")
                                #if type(cell) == float:
                                #   d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip(), style="text-align:right;padding:5px;border:1px solid black;")
                                #elif type(cell) == Decimal:
                                #    d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip(), style="text-align:right;padding:5px;border:1px solid black;")
                                    #d = td(str(cell.quantize(TWOPLACES)).encode('ascii', 'replace').strip())
                                #elif type(cell) == int or type(cell) == long:
                                #    d = td(locale.format( '%d', round(cell), grouping=True).encode('utf-8', 'replace').strip())


                                    #d = td(str(cell.quantize(TWOPLACES)).encode('ascii', 'replace').strip())
                                #elif type(cell) == NoneType:
                                #    d = td(str('NA'), style="text-align:left;padding:5px;border:1px solid black;")
                                #elif type(cell) == str:
                                #    d = td(cell.decode( 'utf-8', 'ignore'), style="text-align:left;padding:5px;border:1px solid black;")
                                #else:
                                #    d = td(cell if type(cell) is unicode else str(cell), style="text-align:left;padding:5px;border:1px solid black;")
                                l += d
                   # with table(border="0",cellpadding="0", cellspacing="0", width="100%", id="footerTable").add(tbody()):
                   #     ftr = tr()
                   #     ftd = td('Report generated at ' + datetime.strftime(datetime.now(), '%Y-%m:%d %H:%M:%S'), align="center",valign="top")
                l1 += d1
        return h


def getLogs(entity_ids,source):
        send_mail_flag = 0
	load_date_check = (datetime.now() - timedelta(days =0)).strftime('%Y%m%d')
        if entity_ids == 'NA':
                pass
        else:
                print "Inside Get Logs"
                source = source.replace('.','_')
                entitylogdir = '/home/npradhan/entity_logs'

                if os.path.exists('%s'%entitylogdir) is False:
                        os.system('mkdir %s'%entitylogdir)
                source=source.replace('/','_')
                os.system('rm -f %s/entity_logs_%s_%s.csv'%(entitylogdir,source,load_date_check))
                f = open('%s/entity_logs_%s_%s.csv'%(entitylogdir,source,load_date_check),'a+')

                for entityID in entity_ids:
			entityID=str(entityID)	
                        command='curl -s --request GET "http://10.208.2.65:8675/podium/entity/v1/loadLogs/'+entityID+'?count=1&sortAttr=loadTime" --cookie cookies.txt'
                        logsPipe = Popen(command, shell=True, stdout=PIPE)
                        logsJson = json.load(logsPipe.stdout)
                        '''if len(load_date_check) < 6:
                                load_date_check = datetime.strptime(load_date_check,'%s'%folderformat)
                                load_date_check = load_date_check.strftime('%s'%folderformat)'''
			if len(logsJson['subList']) > 0 :
                        	if load_date_check in logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8] :
                                	print "Inside load_date_check"
                                	send_mail_flag = 1
                                	if logsJson['subList'][0]['status'] == 'FAILED':
                                        	f.write('%s,%s,%s,%s,%s\n'%(logsJson['subList'][0]['sourceName'],logsJson['subList'][0]['entityName'],logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8],'FAILED',logsJson['subList'][0]['infoMessage'].replace('\n',' ')[0:600]))
                                	else:
                                        	f.write('%s,%s,%s,%s,%s\n'%(logsJson['subList'][0]['sourceName'],logsJson['subList'][0]['entityName'],logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8],'SUCCESS','Data Loaded Successfully'))
						print logsJson['subList'][0]['sourceName'],logsJson['subList'][0]['entityName'],(logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8])
                f.close()
                if send_mail_flag == 1:

                        f = open('%s/entity_logs_%s_%s.csv'%(entitylogdir,source,load_date_check),'r')
                        raw_data = []
                        for i in f:
                                raw_data.append(tuple(i.replace('\n','').split(',')))
                        raw_data = tuple(raw_data)
                        html = generate_html(raw_data, 'Source,Entity,Deliverydate,Status,Info', 'StatusReport')
                        SendMail('PFA',html,source)
        return send_mail_flag


os.system('echo "Welcome@123" | kinit podium')
entites = fetch_source_entity_info('medical_affairs')
print entites
getLogs(entites,'medical_affairs')
