#!/bin/sh
sh scripts/astellas_fusion.sh &
wait
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/astellas_fusion_sa_repactivity_full.hql &
wait
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/astellas_fusion_sa_speaker_program_analytics_workstream.hql &
wait
sh scripts/astellas_fusion_sa.sh &
wait
