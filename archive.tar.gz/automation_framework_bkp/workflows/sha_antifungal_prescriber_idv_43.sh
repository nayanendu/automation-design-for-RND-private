#!/bin/sh
sh scripts/sha_antifungal_prescriber_idv.sh