#!/bin/sh
sh scripts/ims_oncology_emr.sh