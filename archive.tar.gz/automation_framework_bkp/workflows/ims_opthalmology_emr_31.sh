#!/bin/sh
sh scripts/ims_opthalmology_emr.sh