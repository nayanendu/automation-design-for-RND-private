#!/bin/sh

for i in 1 2 3 4 5 6 7
do
echo $i
sleep 4m
done
