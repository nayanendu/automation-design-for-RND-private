#!/bin/sh
sh /home/npradhan/workspace/automation_framework/scripts/ims_open_claims_weekly.sh
wait
folder_date=$1
for i in $(hadoop fs -ls /data/receiving/ims_open_claims_weekly/* | awk '{print $8}' | awk -F'ims_open_claims_weekly/' '{print $2}'| grep -v claims_i | grep -v old | grep $folder_date); do hadoop distcp -Dmapreduce.map.memory.mb=3000 -Dmapreduce.reduce.memory.mb=6000 -Dipc.client.fallback-to-simple-auth-allowed=true -skipcrccheck -update -m 100 /data/receiving/ims_open_claims_weekly/$i/ s3a://astellas-ims/ims_weekly_hdfs/$i/; done;

#now delete hive partitions from podium

python /home/npradhan/workspace/adhoc_monthly_loads/delete_logs_from_podium.py ims_open_claims_weekly $folder_date

#pointing data to S3


for i in $(aws s3 ls s3://astellas-ims/ims_weekly_hdfs/ | awk -F'PRE ' '{print $2}');  do for k in $(aws s3 ls s3://astellas-ims/ims_weekly_hdfs/$i | awk -F'PRE ' '{print $2}' | sort -r ) ; do echo $i$k; beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -e "alter table ims_open_claims_weekly.${i:0:-1} add partition (podium_delivery_date='${k:0:-1}') LOCATION 's3a://AKIAJE6WAVYQRX5EIRCQ:zHXMDnVPeWORoRKUpWD61eK1UtfEKbM2o4SB5STh@astellas-ims/ims_weekly_hdfs/${i:0:-1}/${k:0:-1}/good'" ; done; done
