#!/bin/sh
sh scripts/astellas_supporting_sha_geo.sh