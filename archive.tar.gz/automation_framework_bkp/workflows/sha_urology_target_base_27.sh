#!/bin/sh
sh scripts/sha_urology_target_base.sh