#!/bin/sh
sh scripts/ims_open_claims_weekly.sh
