#!/bin/sh
sh scripts/ims_ambulatory_emr.sh