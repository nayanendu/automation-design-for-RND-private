#!/bin/sh
sh scripts/astellas_supporting_astellas_sales_roster.sh