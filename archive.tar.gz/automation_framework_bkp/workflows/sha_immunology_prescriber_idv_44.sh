#!/bin/sh
sh scripts/sha_immunology_prescriber_idv.sh