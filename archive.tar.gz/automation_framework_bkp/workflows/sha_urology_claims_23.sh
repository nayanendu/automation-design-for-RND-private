#!/bin/sh
sh scripts/sha_urology_claims.sh &
wait
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/sha_urology_claims_sa_patient_activity_full.hql &
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/sha_urology_claims_sa_market_rx_claims_full.hql &
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/sha_urology_claims_sa_diagnosis_claims_full.hql &
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/sha_urology_claims_sa_procedure_claims_full.hql &
wait
sh scripts/sha_urology_claims_sa_patient_activity_full.sh &
sh scripts/sha_urology_claims_sa_market_rx_claims_full.sh &
sh scripts/sha_urology_claims_sa_diagnosis_claims_full.sh &
sh scripts/sha_urology_claims_sa_procedure_claims_full.sh &
wait
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/sha_urology_claims_sa_non_market_rx_claims_full.hql &
beeline -u "jdbc:hive2://usva-prd-en-01:10000/default;principal=hive/usva-prd-en-01@ASTELLAS_US_PRD.COM" -f  scripts/sha_urology_claims_sa_ptd_metrics.hql &
wait
sh scripts/sha_urology_claims_sa_non_market_rx_claims_full.sh &
sh scripts/sha_urology_claims_analytics_ptd_metric.sh &
wait
