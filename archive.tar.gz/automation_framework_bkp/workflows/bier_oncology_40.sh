#!/bin/sh
sh scripts/bier_oncology.sh