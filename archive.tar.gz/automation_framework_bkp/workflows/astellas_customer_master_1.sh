#!/bin/sh
sh scripts/astellas_customer_master.sh