#!/bin/sh
sh scripts/promomix_vesicare_datamax.sh