#!/bin/sh
sh scripts/bier_dw_pt.sh