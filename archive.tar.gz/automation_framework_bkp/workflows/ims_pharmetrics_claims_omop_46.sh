#!/bin/sh
sh scripts/ims_pharmetrics_claims_omop.sh