#!/bin/sh
sh scripts/astellas_supporting_expense_manager.sh