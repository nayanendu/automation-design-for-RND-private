#!/bin/sh
sh scripts/promomix_myrbetriq_datamax.sh