#!/bin/sh
sh scripts/bier_dw.sh