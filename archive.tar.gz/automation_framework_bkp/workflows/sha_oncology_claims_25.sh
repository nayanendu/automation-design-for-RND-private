#!/bin/sh
##sh scripts/sha_oncology_claims.sh
pig -f scripts/sha_oncology_claims_sa_diagnosis_claims_full.pig &
pig -f scripts/sha_oncology_claims_sa_patient_activity_full.pig &
pig -f scripts/sha_oncology_claims_sa_market_rx_claims_full.pig
pig -f scripts/sha_oncology_claims_sa_procedure_claims_full.pig &
pig -f scripts/sha_oncology_claims_sa_non_market_rx_claims_full.pig 
