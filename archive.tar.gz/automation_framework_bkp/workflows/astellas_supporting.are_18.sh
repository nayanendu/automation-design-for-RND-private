#!/bin/sh
sh scripts/astellas_supporting_are.sh