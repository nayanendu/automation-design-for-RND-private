set hive.exec.parallel=true;
set hive.mapred.supports.subdirectories=true;
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=com.hadoop.compression.lzo.LzoCodec;
set hive.exec.compress.output=true;
set mapred.map.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set mapreduce.job.reduces=250;
set optimize.sort.dynamic.partitioning=true;

USE medical_affairs;

DROP TABLE sandbox_medical_affairs.impact_full_tmp00;
DROP TABLE sandbox_medical_affairs.impact_full_tmp01;
DROP TABLE sandbox_medical_affairs.impact_full_tmp02;
DROP TABLE sandbox_medical_affairs.impact_full_tmp03;
DROP TABLE sandbox_medical_affairs.impact_full_tmp04;
DROP TABLE sandbox_medical_affairs.impact_full_tmp05;
DROP TABLE sandbox_medical_affairs.impact_full_tmp06;
DROP TABLE sandbox_medical_affairs.impact_full_tmp07;
DROP TABLE sandbox_medical_affairs.impact_full_tmp08;
DROP TABLE sandbox_medical_affairs.impact_full_tmp09;
DROP TABLE sandbox_medical_affairs.impact_full_tmp10;
DROP TABLE sandbox_medical_affairs.impact_full_tmp11;
DROP TABLE sandbox_medical_affairs.impact_full_tmp12;
DROP TABLE sandbox_medical_affairs.impact_full_tmp13;
DROP TABLE sandbox_medical_affairs.impact_full_tmp14;
DROP TABLE sandbox_medical_affairs.impact_full_tmp15;
DROP TABLE sandbox_medical_affairs.impact_full_tmp16;
DROP TABLE sandbox_medical_affairs.impact_full_tmp17;
DROP TABLE sandbox_medical_affairs.impact_full_tmp18;
DROP TABLE sandbox_medical_affairs.impact_full_tmp19;
DROP TABLE sandbox_medical_affairs.impact_full_tmp20;
DROP TABLE sandbox_medical_affairs.impact_full_tmp21;
DROP TABLE sandbox_medical_affairs.impact_full_tmp22;
DROP TABLE sandbox_medical_affairs.impact_full_tmp23;
DROP TABLE sandbox_medical_affairs.impact_full_tmp24;
DROP TABLE sandbox_medical_affairs.impact_full_tmp25;
DROP TABLE sandbox_medical_affairs.impact_full_tmp26;
DROP TABLE sandbox_medical_affairs.impact_full_tmp27;
DROP TABLE sandbox_medical_affairs.impact_full_tmp28;
DROP TABLE sandbox_medical_affairs.impact_full_tmp29;
DROP TABLE sandbox_medical_affairs.impact_full_tmp30;
DROP TABLE sandbox_medical_affairs.impact_full_tmp31;
DROP TABLE sandbox_medical_affairs.impact_full_tmp32;
DROP TABLE sandbox_medical_affairs.impact_study_full;

CREATE TABLE sandbox_medical_affairs.impact_full_tmp00 AS 
SELECT study.international_no isn
,study.cancel_stop_flag
,com.reporting_ta 
,study.compound
,com.reporting_compound_name
,com.product_scope
,study.eudract_no eudract_number
,study.status study_status
,study.status_no study_status_code
,study.trial_short_desc study_nickname
,study.full_study_title study_short_description
,study.finance_med_unit_code study_sponsor_value
,org1.org_affiliate affiliate
,org1.org_region ma_group
,study.managing_med_unit_code executing_region_value
,org2.org_affiliate executing_region
,org2.org_region executing_region_group
,country.country_name site_country
,study.study_manager
,proj.project_reference
,proj.project_formulation project_level_formulation
,study.phase study_phase
,study.nbr_patients_planned number_of_patients_planned
,study.nbr_patients_enrolled number_of_patients_enrolled
,(study.nbr_patients_enrolled/study.nbr_patients_planned)*100 pct_enrolled
,study.hold_flag on_hold
,study.cancel_stop_flag stopped_cancelled
-- ,study.interventional_indicator interventional
,study.study_type
,study.study_category   
,study.study_category_2          
,CASE 
   WHEN study.regulatory_relevance_code = 'RC' THEN 'Y'
   WHEN study.regulatory_relevance_code = 'RCMAA' THEN 'Y'
   WHEN study.regulatory_relevance_code = 'MS' THEN 'N'
   WHEN study.regulatory_relevance_code = 'MAA' THEN 'N'
   WHEN study.regulatory_relevance_code IS NULL THEN NULL
END as regulatory_commitment
,CASE 
   WHEN study.regulatory_relevance_code = 'RC' THEN 'Regulatory commitment'
   WHEN study.regulatory_relevance_code = 'RCMAA' THEN 'Reg Commitment/MAA'
   WHEN study.regulatory_relevance_code = 'MS' THEN 'Post marketing study'
   WHEN study.regulatory_relevance_code = 'MAA' THEN 'Marketing authorisation approval'
   WHEN study.regulatory_relevance_code IS NULL THEN NULL
END as regulatory_relevance
-- regulatory_relevance     CASE STATEMENT NEEDED  d_study
FROM medical_affairs.impact_d_study study
LEFT JOIN 
    (SELECT com_all.compound_value, com_all.product_scope, com_all.eff_date, com_all.reporting_compound_name, com_all.reporting_ta
     FROM medical_affairs.xref_compounds com_all
     JOIN (SELECT compound_value, max(eff_date) eff_date 
          FROM medical_affairs.xref_compounds
          WHERE compound_value IS NOT NULL
          GROUP BY compound_value) com_max
     ON com_max.compound_value = com_all.compound_value and com_max.eff_date=com_all.eff_date
    ) com
   ON rtrim(ltrim(upper(study.compound))) = rtrim(ltrim(upper(com.compound_value)))
LEFT OUTER JOIN medical_affairs.xref_organization org1
   ON study.finance_med_unit_code = org1.org_value
LEFT OUTER JOIN medical_affairs.xref_organization org2
   ON study.managing_med_unit_code = org2.org_value
LEFT OUTER JOIN 
   (SELECT s.international_no, c.study_no, concat_ws(", ",collect_set(c.country_name)) country_name
      FROM medical_affairs.impact_d_study s
      LEFT JOIN medical_affairs.impact_d_study_country c
      ON s.study_no = c.study_no
      GROUP BY s.international_no, c.study_no) country
   ON study.study_no = country.study_no
LEFT OUTER JOIN (select distinct study.international_no , project.project_reference, project.project_formulation
      from medical_affairs.impact_d_study study
      join medical_affairs.impact_f_event event on study.study_sid = event.study_sid
      join medical_affairs.impact_d_project project on event.project_sid = project.project_sid)  proj
   ON study.international_no = proj.international_no;

CREATE TABLE sandbox_medical_affairs.impact_full_tmp01 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) synopsis_approved_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 2454) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp02 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) synopsis_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 2454) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp03 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) synopsis_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 2454) sub1
   ON event.event_name_sid = sub1. event_name_sid;    

CREATE TABLE sandbox_medical_affairs.impact_full_tmp04 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) protocol_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 2500) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp05 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) protocol_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 2500) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp06 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) protocol_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 2500) sub1
   ON event.event_name_sid = sub1. event_name_sid; 

CREATE TABLE sandbox_medical_affairs.impact_full_tmp07 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) fpi_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3200) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp08 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) fpi_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3200) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp09 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) fpi_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3200) sub1
   ON event.event_name_sid = sub1. event_name_sid; 

CREATE TABLE sandbox_medical_affairs.impact_full_tmp10 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) lpi_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3500) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp11 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) lpi_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3500) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp12 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) lpi_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3500) sub1
   ON event.event_name_sid = sub1. event_name_sid;    
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp13 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) lpo_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3700) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp14 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) lpo_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3700) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp15 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) lpo_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 3700) sub1
   ON event.event_name_sid = sub1. event_name_sid;       

CREATE TABLE sandbox_medical_affairs.impact_full_tmp16 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) dbl_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4000) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp17 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) dbl_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4000) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp18 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) dbl_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4000) sub1
   ON event.event_name_sid = sub1. event_name_sid;       

CREATE TABLE sandbox_medical_affairs.impact_full_tmp19 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) tlr_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4400) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp20 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) tlr_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4400) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp21 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) tlr_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4400) sub1
   ON event.event_name_sid = sub1. event_name_sid;       

CREATE TABLE sandbox_medical_affairs.impact_full_tmp22 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) exec_tlr_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4380) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp23 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) exec_tlr_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4380) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp24 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) exec_tlr_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4380) sub1
   ON event.event_name_sid = sub1. event_name_sid;     

CREATE TABLE sandbox_medical_affairs.impact_full_tmp25 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) tlg_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4500) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp26 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) tlg_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4500) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp27 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) tlg_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4500) sub1
   ON event.event_name_sid = sub1. event_name_sid;        
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp28 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_2_date) as date) csr_approval_baseline_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4650) sub1
   ON event.event_name_sid = sub1. event_name_sid;
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp29 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.plan_3_date) as date) csr_approved_planned_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4650) sub1
   ON event.event_name_sid = sub1. event_name_sid;   
   
CREATE TABLE sandbox_medical_affairs.impact_full_tmp30 AS
SELECT DISTINCT study.international_no isn
,cast(to_date(event.actual_date) as date) csr_approved_actual_date
FROM medical_affairs.impact_d_study study
JOIN medical_affairs.impact_f_event event
   ON study.study_sid = event.study_sid
JOIN (select event_name_sid from medical_affairs.impact_d_event_name where event_no = 4650) sub1
   ON event.event_name_sid = sub1. event_name_sid;  

CREATE TABLE sandbox_medical_affairs.impact_full_tmp31 AS
SELECT 
coalesce(tmp01.isn,tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn,tmp25.isn,tmp26.isn,tmp27.isn,tmp28.isn,tmp29.isn,tmp30.isn) isn
,tmp01.synopsis_approved_baseline_date 
,tmp02.synopsis_approved_planned_date
,tmp03.synopsis_approved_actual_date
,tmp04.protocol_approval_baseline_date
,tmp05.protocol_approved_planned_date
,tmp06.protocol_approved_actual_date
,tmp07.fpi_approval_baseline_date
,tmp08.fpi_approved_planned_date
,tmp09.fpi_approved_actual_date
,tmp10.lpi_approval_baseline_date
,tmp11.lpi_approved_planned_date
,tmp12.lpi_approved_actual_date
,tmp13.lpo_approval_baseline_date
,tmp14.lpo_approved_planned_date
,tmp15.lpo_approved_actual_date 
,tmp16.dbl_approval_baseline_date
,tmp17.dbl_approved_planned_date 
,tmp18.dbl_approved_actual_date 
,tmp19.tlr_approval_baseline_date 
,tmp20.tlr_approved_planned_date 
,tmp21.tlr_approved_actual_date 
,tmp22.exec_tlr_approval_baseline_date 
,tmp23.exec_tlr_approved_planned_date 
,tmp24.exec_tlr_approved_actual_date 
,tmp25.tlg_approval_baseline_date 
,tmp26.tlg_approved_planned_date
,tmp27.tlg_approved_actual_date
,tmp28.csr_approval_baseline_date
,tmp29.csr_approved_planned_date
,tmp30.csr_approved_actual_date
FROM sandbox_medical_affairs.impact_full_tmp01 tmp01
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp02 tmp02
   ON tmp01.isn = tmp02.isn 
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp03 tmp03
   ON coalesce(tmp01.isn, tmp02.isn) = tmp03.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp04 tmp04
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn) = tmp04.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp05 tmp05
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn) = tmp05.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp06 tmp06
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn) = tmp06.isn 
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp07 tmp07
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn) = tmp07.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp08 tmp08
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn) = tmp08.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp09 tmp09
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn) = tmp09.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp10 tmp10
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn) = tmp10.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp11 tmp11
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn) = tmp11.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp12 tmp12
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn) = tmp12.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp13 tmp13
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn) = tmp13.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp14 tmp14
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn) = tmp14.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp15 tmp15
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn) = tmp15.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp16 tmp16
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn) = tmp16.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp17 tmp17
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn) = tmp17.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp18 tmp18
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn) = tmp18.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp19 tmp19
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn) = tmp19.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp20 tmp20
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn) = tmp20.isn 
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp21 tmp21
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn) = tmp21.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp22 tmp22
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn) = tmp22.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp23 tmp23
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn) = tmp23.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp24 tmp24
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn) = tmp24.isn   
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp25 tmp25
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn) = tmp25.isn             
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp26 tmp26
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn,tmp25.isn) = tmp26.isn   
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp27 tmp27
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn,tmp25.isn,tmp26.isn) = tmp27.isn   
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp28 tmp28
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn,tmp25.isn,tmp26.isn,tmp27.isn) = tmp28.isn   
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp29 tmp29
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn,tmp25.isn,tmp26.isn,tmp27.isn,tmp28.isn) = tmp29.isn
FULL OUTER JOIN sandbox_medical_affairs.impact_full_tmp30 tmp30
   ON coalesce(tmp01.isn, tmp02.isn,tmp03.isn,tmp04.isn,tmp05.isn,tmp06.isn,tmp07.isn,tmp08.isn,tmp09.isn,tmp10.isn,tmp11.isn,tmp12.isn,tmp13.isn,tmp14.isn,tmp15.isn,tmp16.isn,tmp17.isn,tmp18.isn,tmp19.isn,tmp20.isn,tmp21.isn,tmp22.isn,tmp23.isn,tmp24.isn,tmp25.isn,tmp26.isn,tmp27.isn,tmp28.isn,tmp29.isn) = tmp30.isn;   

CREATE TABLE sandbox_medical_affairs.impact_full_tmp32 AS
SELECT tmp31.isn
,tmp31.synopsis_approved_baseline_date	
,tmp31.synopsis_approved_planned_date	
,tmp31.synopsis_approved_actual_date
,tmp31.protocol_approval_baseline_date		
,tmp31.protocol_approved_planned_date	
,tmp31.protocol_approved_actual_date	
,tmp31.fpi_approval_baseline_date	
,tmp31.fpi_approved_planned_date		
,tmp31.fpi_approved_actual_date	
,tmp31.lpi_approval_baseline_date
,tmp31.lpi_approved_planned_date		
,tmp31.lpi_approved_actual_date	
,tmp31.lpo_approval_baseline_date	
,tmp31.lpo_approved_planned_date		
,tmp31.lpo_approved_actual_date	
,tmp31.dbl_approval_baseline_date	
,tmp31.dbl_approved_planned_date		
,tmp31.dbl_approved_actual_date	
,tmp31.tlr_approval_baseline_date	
,tmp31.tlr_approved_planned_date	
,tmp31.tlr_approved_actual_date	
,tmp31.exec_tlr_approval_baseline_date	
,tmp31.exec_tlr_approved_planned_date	
,tmp31.exec_tlr_approved_actual_date	
,tmp31.tlg_approval_baseline_date	
,tmp31.tlg_approved_planned_date		
,tmp31.tlg_approved_actual_date	
,tmp31.csr_approval_baseline_date	
,tmp31.csr_approved_planned_date	
,tmp31.csr_approved_actual_date
,datediff(to_date(CURRENT_DATE),tmp31.lpi_approved_actual_date) duration_since_since_lpo
,datediff(to_date(CURRENT_DATE),tmp31.exec_tlr_approved_actual_date) duration_since_tlr
,datediff(to_date(CURRENT_DATE),tmp31.dbl_approved_actual_date) duration_since_dbl
,datediff(to_date(CURRENT_DATE),tmp31.csr_approved_actual_date) duration_since_csr
,datediff(protocol_approved_planned_date, protocol_approval_baseline_date) pad_baseline_to_planned_duration 
,datediff(fpi_approved_planned_date, fpi_approval_baseline_date) fpi_baseline_to_planned_duration 
,datediff(lpi_approved_planned_date, lpi_approval_baseline_date) lpi_baseline_to_planned_duration 
,datediff(lpo_approved_planned_date, lpo_approval_baseline_date) lpo_baseline_to_planned_duration 
,datediff(dbl_approved_planned_date, dbl_approval_baseline_date) dbl_baseline_to_planned_duration 
,datediff(tlr_approved_planned_date, tlr_approval_baseline_date) tlr_baseline_to_planned_duration 
,datediff(csr_approved_planned_date, csr_approval_baseline_date) csr_baseline_to_planned_duration 
,datediff(to_date(CURRENT_DATE), tmp31.protocol_approved_planned_date) time_to_protocol_approval
,datediff(to_date(CURRENT_DATE), tmp31.fpi_approved_actual_date) time_to_fpi 
,datediff(to_date(CURRENT_DATE), tmp31.lpi_approved_actual_date	) time_to_lpi 
,datediff(to_date(CURRENT_DATE), tmp31.lpo_approved_actual_date	) time_to_lpo 
,datediff(to_date(CURRENT_DATE), tmp31.dbl_approved_planned_date) time_to_dbl 
,datediff(to_date(CURRENT_DATE), tmp31.tlr_approved_planned_date) time_to_tlr 
,datediff(to_date(CURRENT_DATE), tmp31.csr_approved_planned_date) time_to_csr 
FROM sandbox_medical_affairs.impact_full_tmp31 tmp31;

CREATE TABLE sandbox_medical_affairs.impact_study_full AS 
SELECT tmp00.isn
,tmp00.reporting_ta
,tmp00.compound
,tmp00.reporting_compound_name
,tmp00.product_scope
,tmp00.eudract_number
,tmp00.study_status
,tmp00.study_status_code
,CASE 
   WHEN tmp32.protocol_approved_actual_date IS NULL AND tmp32.csr_approved_actual_date IS NULL  THEN  'No Activity Started'
   WHEN tmp32.protocol_approved_actual_date IS NOT NULL AND tmp32.csr_approved_actual_date IS NULL  THEN  'Ongoing'
   WHEN tmp32.csr_approved_actual_date IS NULL AND tmp32.csr_approved_actual_date IS NULL  THEN  'Completed'
   WHEN tmp00.cancel_stop_flag = 'Yes' THEN 'Cancelled'
 END as tactic_status
,tmp00.study_nickname
,tmp00.study_short_description
,tmp00.study_sponsor_value
,tmp00.affiliate
,tmp00.ma_group
,tmp00.executing_region_value
,tmp00.executing_region
,tmp00.executing_region_group
,tmp00.site_country
,tmp00.study_manager
,tmp00.project_reference
,tmp00.project_level_formulation
,tmp00.study_phase
,tmp00.number_of_patients_planned
,tmp00.number_of_patients_enrolled
,tmp00.pct_enrolled
,tmp00.on_hold
,tmp00.stopped_cancelled
-- ,tmp00.interventional
,tmp00.study_type
,tmp00.study_category
,tmp00.study_category_2
,tmp00.regulatory_commitment
,tmp00.regulatory_relevance
,tmp32.synopsis_approved_baseline_date
,tmp32.synopsis_approved_planned_date
,tmp32.synopsis_approved_actual_date
,tmp32.protocol_approval_baseline_date
,tmp32.protocol_approved_planned_date
,tmp32.protocol_approved_actual_date
,tmp32.fpi_approval_baseline_date
,tmp32.fpi_approved_planned_date
,tmp32.fpi_approved_actual_date
,tmp32.lpi_approval_baseline_date
,tmp32.lpi_approved_planned_date
,tmp32.lpi_approved_actual_date
,tmp32.lpo_approval_baseline_date
,tmp32.lpo_approved_planned_date
,tmp32.lpo_approved_actual_date
,tmp32.dbl_approval_baseline_date
,tmp32.dbl_approved_planned_date
,tmp32.dbl_approved_actual_date
,tmp32.tlr_approval_baseline_date
,tmp32.tlr_approved_planned_date
,tmp32.tlr_approved_actual_date
,tmp32.exec_tlr_approval_baseline_date
,tmp32.exec_tlr_approved_planned_date
,tmp32.exec_tlr_approved_actual_date
,tmp32.tlg_approval_baseline_date
,tmp32.tlg_approved_planned_date
,tmp32.tlg_approved_actual_date
,tmp32.csr_approval_baseline_date
,tmp32.csr_approved_planned_date
,tmp32.csr_approved_actual_date
,tmp32.duration_since_since_lpo
,tmp32.duration_since_tlr
,tmp32.duration_since_dbl
,tmp32.duration_since_csr
,tmp32.pad_baseline_to_planned_duration
,tmp32.fpi_baseline_to_planned_duration
,tmp32.lpi_baseline_to_planned_duration
,tmp32.lpo_baseline_to_planned_duration
,tmp32.dbl_baseline_to_planned_duration
,tmp32.tlr_baseline_to_planned_duration
,tmp32.csr_baseline_to_planned_duration
,tmp32.time_to_protocol_approval
,tmp32.time_to_fpi
,tmp32.time_to_lpi
,tmp32.time_to_lpo
,tmp32.time_to_dbl
,tmp32.time_to_tlr
,tmp32.time_to_csr
FROM sandbox_medical_affairs.impact_full_tmp00 tmp00
LEFT JOIN sandbox_medical_affairs.impact_full_tmp32 tmp32
ON tmp00.isn = tmp32.isn;

DROP TABLE sandbox_medical_affairs.impact_full_tmp00;
DROP TABLE sandbox_medical_affairs.impact_full_tmp01;
DROP TABLE sandbox_medical_affairs.impact_full_tmp02;
DROP TABLE sandbox_medical_affairs.impact_full_tmp03;
DROP TABLE sandbox_medical_affairs.impact_full_tmp04;
DROP TABLE sandbox_medical_affairs.impact_full_tmp05;
DROP TABLE sandbox_medical_affairs.impact_full_tmp06;
DROP TABLE sandbox_medical_affairs.impact_full_tmp07;
DROP TABLE sandbox_medical_affairs.impact_full_tmp08;
DROP TABLE sandbox_medical_affairs.impact_full_tmp09;
DROP TABLE sandbox_medical_affairs.impact_full_tmp10;
DROP TABLE sandbox_medical_affairs.impact_full_tmp11;
DROP TABLE sandbox_medical_affairs.impact_full_tmp12;
DROP TABLE sandbox_medical_affairs.impact_full_tmp13;
DROP TABLE sandbox_medical_affairs.impact_full_tmp14;
DROP TABLE sandbox_medical_affairs.impact_full_tmp15;
DROP TABLE sandbox_medical_affairs.impact_full_tmp16;
DROP TABLE sandbox_medical_affairs.impact_full_tmp17;
DROP TABLE sandbox_medical_affairs.impact_full_tmp18;
DROP TABLE sandbox_medical_affairs.impact_full_tmp19;
DROP TABLE sandbox_medical_affairs.impact_full_tmp20;
DROP TABLE sandbox_medical_affairs.impact_full_tmp21;
DROP TABLE sandbox_medical_affairs.impact_full_tmp22;
DROP TABLE sandbox_medical_affairs.impact_full_tmp23;
DROP TABLE sandbox_medical_affairs.impact_full_tmp24;
DROP TABLE sandbox_medical_affairs.impact_full_tmp25;
DROP TABLE sandbox_medical_affairs.impact_full_tmp26;
DROP TABLE sandbox_medical_affairs.impact_full_tmp27;
DROP TABLE sandbox_medical_affairs.impact_full_tmp28;
DROP TABLE sandbox_medical_affairs.impact_full_tmp29;
DROP TABLE sandbox_medical_affairs.impact_full_tmp30;
DROP TABLE sandbox_medical_affairs.impact_full_tmp31;
DROP TABLE sandbox_medical_affairs.impact_full_tmp32;
