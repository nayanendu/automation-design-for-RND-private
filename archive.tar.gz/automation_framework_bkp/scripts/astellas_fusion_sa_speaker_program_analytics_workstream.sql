DROP TABLE sa_work.spkr_prgm_attendee_tmp1 ;
DROP TABLE sa_work.sap_ccm_mapping_affl;
DROP TABLE sa_work.sap_ccm_mapping_zip ;
DROP TABLE sa_work.sap_ccm_mapping_addr;
DROP TABLE sa_work.spkr_prgm_attendee_final ;
DROP TABLE sa_work.spkr_prgm_attendee_counts_tmp2;
DROP TABLE sa_work.spkr_prgm_speaker_final;
DROP TABLE sa_work.spkr_prgm_speaker_counts_tmp1 ;
DROP TABLE sa_work.spkr_prgm_expenses_tmp2;
DROP TABLE sa_work.spkr_prgm_event_final ;
DROP TABLE sa_work.spkr_prgm_event_oncology_final ;


SET mapred.reduce.tasks=20;
SET hive.exec.parallel=TRUE;

DROP TABLE sa_work.spkr_prgm_attendee_tmp1;	

CREATE TABLE sa_work.spkr_prgm_attendee_tmp1 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
	SELECT 
		attd.id																								AS id
		,evt.id																								AS event_fsn_id
		,CASE 
		WHEN NVL(LTRIM(RTRIM(upper(acct.professional_type))),'NULL')<>'NULL'
			  AND LTRIM(RTRIM(acct.professional_type))<>""
		THEN LTRIM(RTRIM(UPPER(acct.professional_type)))
		
		WHEN (NVL(LTRIM(RTRIM(upper(acct.professional_type))),'NULL')='NULL' 
			  OR LTRIM(RTRIM(acct.professional_type))="" ) 
			  AND 
			  (NVL(LTRIM(RTRIM(upper(attd.professional_type__c))),'NULL')<>'NULL'
			  AND LTRIM(RTRIM(attd.professional_type__c))<>"")
		THEN LTRIM(RTRIM(UPPER(attd.professional_type__c)))
		
		WHEN (NVL(LTRIM(RTRIM(upper(acct.professional_type))),'NULL')='NULL' 
			  OR LTRIM(RTRIM(acct.professional_type))="" ) 
			  AND 
			  (NVL(LTRIM(RTRIM(upper(attd.professional_type__c))),'NULL')='NULL' 
			  OR LTRIM(RTRIM(attd.professional_type__c))="" ) 
		THEN "UNKNOWN"  
		ELSE "ERROR" END																					AS Professional_type
		,acct.id																							AS attendee_account_id
		,acct.primary_account_affiliation_ht																AS primary_account_affiliation	
		,acct.sha_rel_gid																					AS SHA_ID
		,acct.ccm_eid																						AS CCM_EID
		,acct.np_external_id																				AS ECM_ID	
		,acct.me																							AS ME_NUMBER
		,acct.npi_vod																						AS NPI_ID
		,attd.status_vod__c																					AS attendee_status	
		,LTRIM(RTRIM(upper(attd.attendee_name_vod__c)))														AS attendee_name
		,LTRIM(RTRIM(upper(attd.ast_astellas_specialty_description__c)))									AS attendee_specialty
		,LTRIM(RTRIM(upper(attd.ast_sha_specialty__c)))														AS attendee_sha_specialty
		,Mast.entityid																						AS entity_id
		,mp.dataproviderid 																					AS dataproviderid
		,evt.ast_em_meal_type__c																			AS event_meal_type
		,attd.ast_meal_opt_out__c																			AS attendee_meal_opt_out
		,evt.status_vod__c																					AS event_status			
		,evt.start_time_vod__c																				AS event_date
		,evt.program_type__c																				AS event_type	
		,evt.ast_em_program_subtype__c																		AS event_sub_type
		,cat.name_vod__c																					AS event_topic
		,cat.description_vod__c																				AS event_topic_description
		,evt.title_description__c																			AS event_title
		,evt.ast_em_product__c																				AS product
		,evt.em_product_ta__c
        ,evt.em_branded_unbranded__c
		,NVL(UPPER(ta.TA),"UNKNOWN")																		AS therapeutic_area
		,CASE WHEN NVL(LTRIM(RTRIM(acct.ccm_eid)),'NULL')='NULL' 
			  OR LTRIM(RTRIM(acct.ccm_eid))='' 
			  THEN 'true'
			  WHEN NVL(LTRIM(RTRIM(acct.ccm_eid)),'NULL')<>'NULL' 
			  AND LTRIM(RTRIM(acct.ccm_eid))<>''
			  THEN 'false'
	          ELSE "ERROR" END 																				AS walk_ins			
	FROM astellas_fusion.sp_event evt
	
	JOIN astellas_fusion.sp_attendee attd 											
		ON evt.id = attd.event_vod__c 
		AND UPPER(attd.isdeleted) = 'FALSE'
	
	LEFT JOIN astellas_fusion.account acct 
		ON attd.account_vod__c=acct.id
		AND UPPER(acct.isdeleted) = 'FALSE' 	
	
	LEFT JOIN astellas_fusion.sp_catalog cat 										
		ON evt.topic_vod__c = cat.id 
		AND UPPER(cat.isdeleted) = 'FALSE' 
	
	LEFT JOIN bier_oncology.hcp_master Mast
		ON acct.ccm_eid=mast.astellasid
	
	LEFT JOIN bier_oncology.hcp_mapping mp
		ON Mast.entityid=mp.tpsentityid
		AND TRIM(UPPER(mp.dataprovider))="PRM"
	
	LEFT JOIN sa_work.TA_mapping ta 
		ON TRIM(UPPER(evt.ast_em_product__c))=TRIM(UPPER(ta.product))
	
	WHERE UPPER(evt.isdeleted) = 'FALSE' 
		AND UPPER(attd.status_vod__c) NOT LIKE '%DECLINED%'							
		AND UPPER(attd.status_vod__c) NOT LIKE '%SHOW%'								
		AND UPPER(attd.ast_em_attendee_type__c) NOT LIKE 'USER'						
		AND UPPER(evt.status_vod__c) LIKE '%RECONCILE%'
		;

DROP TABLE sa_work.sap_ccm_mapping_affl;

CREATE TABLE sa_work.sap_ccm_mapping_affl
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
SELECT
 p.ccm_child_eid                                         AS attendee_ccm_id
,x.ccm_eid                                               AS account_ccm_id
,x.src_sys_mem_id                                        AS SAP_ID
,p.primary_ind                                           AS primary_affiliation
,rank() OVER (PARTITION BY p.ccm_child_eid 
 ORDER BY p.primary_ind, x.ccm_eid DESC)                 AS rank

FROM astellas_customer_master.org_source_xref x
JOIN astellas_customer_master.prof_affiliation P
ON x.ccm_eid = p.ccm_parent_eid

WHERE UPPER(x.src_sys_nm)="ORGSAP"
AND UPPER(x.ccm_active_ind)="Y";


DROP TABLE sa_work.sap_ccm_mapping_zip ;

CREATE TABLE sa_work.sap_ccm_mapping_zip
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
select F.*
,Rank() OVER(PARTITION BY F.attd_ccm 
ORDER BY F.attd_zip, F.acct_ccm desc)  AS RANK 
FROM
(
select 
distinct 
B.attd_ccm
,B.attd_zip
,C.acct_ccm
,C.sap_id
,C.acct_zip
from 
(
select distinct 
A.ccm_eid            AS attd_ccm
,pd.postal_cd_std    AS  attd_zip
from 
(
select distinct ccm_eid from sa_work.spkr_prgm_attendee_tmp1
WHERE (CCM_EID IS NOT NULL OR CCM_EID<>"") 
) A
LEFT JOIN 
astellas_customer_master.prof_demographics pd
ON A.ccm_eid=pd.ccm_eid
AND pd.postal_cd_std IS NOT NULL 
AND pd.postal_cd_std <>""  
) B --- gives you a list of attendees with respective postal code 

JOIN 
(
select distinct
x.ccm_eid              AS acct_ccm
,x.src_sys_mem_id      AS sap_id
,d.postal_cd           AS acct_zip
from astellas_customer_master.org_source_xref x
LEFT JOIN
astellas_customer_master.org_address_detail d
on x.ccm_eid=d.ccm_eid
where upper(x.src_sys_nm)="ORGSAP"
AND d.postal_cd IS NOT NULL 
AND d.postal_cd <>""
) C

on B.attd_zip=C.acct_zip
) F;


 
DROP TABLE sa_work.sap_ccm_mapping_addr;
CREATE TABLE sa_work.sap_ccm_mapping_addr
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
Select 
F.*
,Rank() OVER(PARTITION BY F.attd_ccm 
ORDER BY F.attd_zip, F.acct_ccm desc)  AS RANK 
from
(
select 
distinct 
B.attd_ccm
,B.attd_addr
,B.attd_zip
,c.acct_ccm
,c.sap_id
,c.acct_addr
,C.acct_zip
from 
(
select distinct 
A.ccm_eid                        AS attd_ccm
,TRIM(UPPER(pd.addr_line1))		 AS attd_addr
,TRIM(UPPER(pd.postal_cd_std))   AS attd_zip

from 
(
select distinct ccm_eid from sa_work.spkr_prgm_attendee_tmp1
WHERE (CCM_EID IS NOT NULL OR CCM_EID<>"") 
) A
LEFT JOIN 
astellas_customer_master.prof_demographics pd
ON A.ccm_eid=pd.ccm_eid
AND pd.postal_cd_std IS NOT NULL 
AND pd.postal_cd_std <>""  
AND pd.addr_line1 IS NOT NULL 
AND pd.addr_line1 <>""
) B --- gives you a list of attendees with respective postal code 

JOIN 
(
select distinct
x.ccm_eid                           AS acct_ccm
,x.src_sys_mem_id                   AS sap_id
,TRIM(UPPER(d.addr_line1))          AS acct_addr
,TRIM(UPPER(d.postal_cd))           AS acct_zip
from astellas_customer_master.org_source_xref x
LEFT JOIN
astellas_customer_master.org_address_detail d
on x.ccm_eid=d.ccm_eid
where upper(x.src_sys_nm)="ORGSAP"
AND d.postal_cd IS NOT NULL 
AND d.postal_cd <>""
AND d.addr_line1 IS NOT NULL
AND d.addr_line1 <>""
) C

on B.attd_zip=C.acct_zip
AND TRIM(UPPER(B.attd_addr))=TRIM(UPPER(C.acct_addr))
) F;


DROP TABLE sa_work.spkr_prgm_attendee_final;

CREATE TABLE sa_work.spkr_prgm_attendee_final 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
	SELECT
	    tmp1.* 
		,NVL(TRIM(pd.phone1_num), "0000000000")                                 	AS CUSTOMER_PHONE_NUM
		,NVL(UPPER(pd.email1_addr), "UNKNOWN")                                   	AS CUSTOMER_EMAIL
		,pd.ama_no_contact_flg 														AS AMA_NO_CONTACT_FLAG
		,pd.pdrp_flg 																AS PDRP_FLAG
		,CASE 
        
             WHEN (tmp1.SHA_ID IS NOT NULL AND LTRIM(RTRIM(tmp1.SHA_ID))<>'')
               OR (tmp1.dataproviderid IS NOT NULL AND LTRIM(RTRIM(tmp1.dataproviderid))<>'')  
             THEN 'WRITER' 
			 
             WHEN (tmp1.SHA_ID IS NULL OR LTRIM(RTRIM(tmp1.SHA_ID))='') 
			  AND (tmp1.dataproviderid IS NULL OR LTRIM(RTRIM(tmp1.dataproviderid))='')  
			  THEN NVL(LTRIM(RTRIM(UPPER(am.attd_category))),"UNKNOWN")
		      ELSE "ERROR" END 														AS ATTENDEE_TYPE
			  
			
		,act.sap_ht 																AS SAP_ID_PRIM_AFF
		,M1.SAP_ID																	AS SAP_ID_OTHER_AFF
        ,M2.SAP_ID                                                                  AS SAP_ID_ADDR
        ,M3.SAP_ID                                                                  AS SAP_ID_ZIP  		
        FROM sa_work.spkr_prgm_attendee_tmp1 tmp1 
		
		LEFT JOIN sa_work.attd_mapping am
		ON LTRIM(RTRIM(UPPER(tmp1.professional_type))) = LTRIM(RTRIM(UPPER(am.attd_credentials)))
		AND TRIM(UPPER(tmp1.therapeutic_area)) = TRIM(UPPER(am.therapeutic_area))
		
		LEFT JOIN astellas_fusion.account act
        ON tmp1.primary_account_affiliation=act.id 
		AND UPPER(act.isdeleted) = 'FALSE' 
		
		LEFT JOIN sa_work.sap_ccm_mapping_affl M1
		ON  tmp1.CCM_EID = M1.attendee_ccm_id
		AND M1.Rank=1
		
		LEFT JOIN sa_work.sap_ccm_mapping_addr M2
		ON  tmp1.CCM_EID = M2.attd_ccm
		AND M2.Rank=1
		
		LEFT JOIN sa_work.sap_ccm_mapping_zip M3
		ON  tmp1.CCM_EID = M3.attd_ccm
		AND M3.Rank=1
		
		LEFT JOIN astellas_customer_master.prof_demographics pd
		on tmp1.ccm_eid=pd.ccm_eid
		
		WHERE LTRIM(RTRIM(UPPER(tmp1.professional_type))) <> "VENDOR";



DROP TABLE sa_work.spkr_prgm_attendee_counts_tmp2;

CREATE TABLE sa_work.spkr_prgm_attendee_counts_tmp2
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
SELECT 
attf.event_fsn_id
,SUM(CASE 	WHEN LTRIM(RTRIM(lower(attf.walk_ins)))='true'	 					
			THEN 1 
			WHEN LTRIM(RTRIM(lower(attf.walk_ins)))='false' 	 
			THEN 0
			ELSE 0 END) 											AS count_of_walk_ins		
,SUM(CASE	WHEN LTRIM(RTRIM(UPPER(attf.Attendee_type)))='WRITER' 
			THEN 1
			WHEN LTRIM(RTRIM(UPPER(attf.Attendee_type)))<>'WRITER' 
			THEN 0											
			ELSE 0 END)												AS count_of_writers
,SUM(CASE	WHEN LTRIM(RTRIM(UPPER(attf.Attendee_type)))='INFLUENCER' 
			THEN 1
			WHEN LTRIM(RTRIM(UPPER(attf.Attendee_type)))<>'INFLUENCER' 
			THEN 0											
			ELSE 0 END)												AS count_of_influencers			
,SUM(CASE	WHEN LTRIM(RTRIM(UPPER(attf.Attendee_type)))='NON INFLUENCER' 
			THEN 1
			WHEN LTRIM(RTRIM(UPPER(attf.Attendee_type)))<>'NON INFLUENCER' 
			THEN 0											
			ELSE 0 END)												AS count_of_non_influencers
from sa_work.spkr_prgm_attendee_final attf
GROUP BY attf.event_fsn_id;


DROP TABLE sa_work.spkr_prgm_speaker_final;

CREATE TABLE sa_work.spkr_prgm_speaker_final 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
	SELECT 
		spkr.id											AS id
		,spkr.speaker_vod__c							AS speaker_fusion_id
		,spkr.account_vod__c							AS speaker_account_id
		,spkr.speaker_name_vod__c						AS speaker_name
		,spkr.ast_speaker_identifier__c					AS speaker_specialty
		,spkr.ast_astellas_specialty_description__c		AS speaker_specialty_desc
		,acct.professional_type							AS speaker_prof_type
		,eh.actual_vod__c								AS speaker_expense 
		,Mast.entityid									AS entity_id
		,mp.dataproviderid 								AS dataproviderid
		,acct.sha_rel_gid								AS SHA_ID
		,acct.ccm_eid									AS CCM_EID
		,acct.np_external_id							AS ECM_ID	
		,acct.me										AS ME_NUMBER
		,acct.npi_vod									AS NPI_ID
		,NVL(TRIM(pd.phone1_num), "0000000000")         AS CUSTOMER_PHONE_NUM
		,NVL(UPPER(pd.email1_addr), "UNKNOWN")          AS CUSTOMER_EMAIL
		,pd.ama_no_contact_flg                          AS AMA_NO_CONTACT_FLAG
		,pd.pdrp_flg                                    AS PDRP_FLAG
		,acct.credentials_vod							AS attendee_acct_credential
		,evt.ast_em_meal_type__c						AS event_meal_type
		,spkr.meal_opt_in_vod__c						AS speaker_meal_opt_in
		,evt.ast_em_product__c							AS product
		,evt.id											AS event_fsn_id 
		,evt.status_vod__c								AS event_status			
		,evt.start_time_vod__c							AS event_date
		,evt.program_type__c							AS event_type	
		,evt.ast_em_program_subtype__c					AS event_sub_type
		,cat.name_vod__c								AS event_topic
		,cat.description_vod__c							AS event_topic_description
		,evt.em_product_ta__c
        ,evt.em_branded_unbranded__c
	FROM astellas_fusion.sp_event evt
	
	JOIN astellas_fusion.sp_event_speaker spkr 								
		ON evt.id = spkr.event_vod__c 		
		AND UPPER(spkr.isdeleted) = 'FALSE'
	
	LEFT JOIN astellas_fusion.account acct 
		ON spkr.account_vod__c = acct.id 
		AND UPPER(acct.isdeleted) = 'FALSE' 		
	
	LEFT JOIN bier_oncology.hcp_master Mast
		ON acct.ccm_eid=mast.astellasid
	
	LEFT JOIN bier_oncology.hcp_mapping mp
		ON Mast.entityid=mp.tpsentityid
		AND TRIM(UPPER(mp.dataprovider))="PRM"

	LEFT JOIN astellas_fusion.sp_catalog cat 								
		ON evt.topic_vod__c = cat.id 
		AND UPPER(cat.isdeleted) = 'FALSE' 
		
	LEFT JOIN astellas_fusion.sp_expense_header eh
		ON UPPER(spkr.id)=upper(eh.incurred_expense_speaker_vod__c)
		AND incurred_expense_speaker_vod__c IS NOT NULL 
		AND incurred_expense_speaker_vod__c<>""
		AND lower(eh.isdeleted)='false'
		
	LEFT JOIN astellas_customer_master.prof_demographics pd
		on acct.ccm_eid=pd.ccm_eid	
	
	WHERE 
		UPPER(evt.isdeleted) = 'FALSE' 
		AND UPPER(spkr.status_vod__c) NOT LIKE '%DECLINED%'					
		AND UPPER(spkr.status_vod__c) NOT LIKE '%SHOW%'						
		AND UPPER(evt.status_vod__c) LIKE '%RECONCILE%';


DROP TABLE sa_work.spkr_prgm_speaker_counts_tmp1;

CREATE TABLE sa_work.spkr_prgm_speaker_counts_tmp1 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
SELECT 
sf.event_fsn_id
,count(id) AS count_of_id
,count(distinct speaker_fusion_id) AS count_of_speaker_fusion_id
,count(speaker_account_id) AS count_of_speaker_account_id
from sa_work.spkr_prgm_speaker_final	sf
GROUP BY sf.event_fsn_id;


DROP TABLE sa_work.spkr_prgm_expenses_tmp2;

CREATE TABLE sa_work.spkr_prgm_expenses_tmp2
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
AS
select
	ev.id  event_fsn_id

	,SUM(CASE when eh.event_vod__c IS NOT NULL
			THEN( 
					CASE 
						WHEN ltrim(rtrim(eh.incurred_expense_speaker_vod__c))<>'' 
						AND ltrim(rtrim(eh.incurred_expense_speaker_vod__c)) IS NOT NULL 
						THEN CAST(CAST(eh.actual_vod__c AS DOUBLE) AS INT)
						ELSE 0 END
				)                                                    
			ELSE NULL END) 														AS speaker_expense  			
																
								
	,SUM(
		CASE 
			WHEN ltrim(rtrim(eh.incurred_expense_speaker_vod__c))='' 
			OR ltrim(rtrim(eh.incurred_expense_speaker_vod__c)) IS NULL 
			THEN CAST(CAST(eh.actual_vod__c AS DOUBLE) AS INT)
			ELSE 0 END)															 AS other_event_expense
FROM astellas_fusion.sp_event ev

LEFT JOIN astellas_fusion.sp_expense_header eh
on ev.id=eh.event_vod__c
AND lower(eh.isdeleted)='false'

WHERE UPPER(ev.isdeleted) = 'FALSE'
AND UPPER(ev.status_vod__c) LIKE '%RECONCILE%'
GROUP BY ev.id	;


DROP TABLE sa_work.spkr_prgm_event_final;


create table sa_work.spkr_prgm_event_final 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
as
	SELECT 
		evt.id																	AS event_fsn_id 
		,evt.ast_event_request_id__c                                            AS event_request_id
		,evt.status_vod__c														AS event_status			
		,substring(evt.start_time_vod__c,1,10)									AS event_date			
		,evt.program_type__c													AS event_type			
		,evt.ast_em_program_subtype__c											AS event_sub_type
		,evt.title_description__c                                               AS event_title
		,cat.name_vod__c														AS event_topic			
		,cat.description_vod__c													AS event_topic_description
		,A.budget_id                                                            AS event_budget_id
		,UPPER(TRIM(A.budget_name))                                             AS event_budget_name
		,v.id																	AS venue_fsn_id
        ,v.ast_venue_name__c													AS venue_name
        ,v.city_vod__c															AS venue_city
        ,v.state_province_vod__c												AS venue_state		
		,evt.ownerid															AS astellas_rep_id
		,usr.name																AS astellas_rep_name
		,T.TERRITORY_NUMBER_AST__C            									AS territory_id
		,T.name																	AS territory	
		,evt.ast_em_product__c													AS product
		,ta.TA																	AS therapeutic_area
		,CAST(CAST(evt.ast_actual_attendance__c AS DOUBLE) AS INT)				AS event_attendee_actual
		,CAST(CAST(evt.estimated_attendance_vod__c as DOUBLE) as INT)			AS event_attendee_estimated
		,CAST(CAST(evt.ast_count_of_current_attendees__c as DOUBLE) as INT)		AS event_attendee_estimated2 
		,CAST(CAST(evt.ast_count_of_speakers__c as DOUBLE) as INT)				AS event_speakers_estimated 
		,evt.actual_cost_vod__c													AS event_expense_actual_fromspevent	
		,exp.speaker_expense													AS event_speaker_expense
		,exp.other_event_expense												AS event_other_expense
		,spcnt.count_of_speaker_fusion_id										AS count_of_speakers
		,atcnt.count_of_walk_ins												AS count_of_walk_ins
		,atcnt.count_of_writers													AS count_of_writers
		,atcnt.count_of_influencers												AS count_of_influencers
		,atcnt.count_of_non_influencers											AS count_of_non_influencers
		,evt.em_product_ta__c
        ,evt.em_branded_unbranded__c			
	FROM astellas_fusion.sp_event evt 
	
	LEFT JOIN astellas_fusion.sp_venue v
	ON evt.venue_vod__c=v.id
	AND UPPER(v.isdeleted) = 'FALSE' 
		
	LEFT JOIN astellas_fusion.sp_catalog cat 								
		ON evt.topic_vod__c = cat.id 
		AND UPPER(cat.isdeleted) = 'FALSE' 
		
	LEFT JOIN sa_work.spkr_prgm_expenses_tmp2 exp	
		ON evt.id=exp.event_fsn_id
		
	LEFT JOIN sa_work.spkr_prgm_speaker_counts_tmp1 spcnt
		ON evt.id=spcnt.event_fsn_id
		
	LEFT JOIN sa_work.spkr_prgm_attendee_counts_tmp2 atcnt
		ON evt.id=atcnt.event_fsn_id
		
	LEFT JOIN astellas_fusion.user usr 
		ON evt.ownerid = usr.id
	
	LEFT JOIN 
		( 
			select a.userid, a.territoryid, a.systemmodstamp
			from astellas_fusion.user_territory a
			JOIN
				(
					select userid, MAX(systemmodstamp) sysmod
					from astellas_fusion.user_territory 
					WHERE TRIM(lower(isactive))='true' 
					GROUP BY userid 
				) b
			on a.userid=b.userid
			AND a.systemmodstamp=b.sysmod
 		) UT 
       ON usr.id = UT.userid  
     
	LEFT JOIN astellas_fusion.territory T 
		ON UT.territoryid = T.id
				
	LEFT JOIN sa_work.TA_mapping ta 
		ON LTRIM(RTRIM(UPPER(evt.ast_em_product__c)))=TRIM(UPPER(ta.product))	
		
	LEFT JOIN 
    	(
			select 
			eb.budget_vod__c as budget_id
			, b.name as budget_name
			, eb.event_vod__c as evt_id 
			from astellas_fusion.sp_budget b
			INNER JOIN astellas_fusion.sp_event_budget eb
			on b.id=eb.budget_vod__c
			where eb.event_vod__c<>""
		)A 
		ON evt.id=A.evt_id
        
    WHERE UPPER(evt.isdeleted) = 'FALSE'    
	AND UPPER(evt.status_vod__c) LIKE '%RECONCILE%';


DROP TABLE sa_work.spkr_prgm_event_oncology_final;


create table sa_work.spkr_prgm_event_oncology_final 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
as
	SELECT 
		evt.*
		,CASE 
		WHEN upper(evt.event_title) like "%METASTATIC CASTRATION-RESISTANT PROSTATE CANCER%"
		AND upper(evt.event_title) like "%TARGETING THE ANDROGEN RECEPTOR SIGNALING PATHWAY%"
		AND upper(evt.event_title) like "%XTANDI%"
		THEN "PHYSICIAN"
		
		WHEN upper(evt.event_title) like "%YOU COVERED%"
		THEN "REIMBURSEMENT"
		
		WHEN upper(evt.event_title) like "%CONTINUING CARE FOR YOUR PATIENTS%" 
		AND (upper(evt.event_title) like "%MCRPC%" OR upper(evt.event_title) like "%METASTATIC CRPC%") 
		THEN "PHYSICIAN"
		
		WHEN upper(evt.event_title) like "%MANAGING PATIENTS WITH XTANDI%" 
		AND upper(evt.event_title) like "%HEALTHCARE TEAM%" 
		AND upper(evt.event_title) like "%TREATMENT OVERVIEW%" 
		THEN "NURSE" 
		
		WHEN upper(evt.event_title) like "%PATIENT CARE%" 
		AND upper(evt.event_title) like "%METASTATIC CRPC%" 
		AND upper(evt.event_title) like "%ROLE OF XTANDI%" 
		THEN "NURSE"
		
		WHEN upper(evt.event_title) like "%ROLE OF XTANDI%" 
		AND upper(evt.event_title) like "%METASTATIC CRPC%" 
		AND UPPER(evt.event_title) NOT LIKE "%PATIENT CARE%"
		THEN "PHYSICIAN"
		
		WHEN upper(evt.event_title) like "%CARING FOR METASTATIC CRPC PATIENTS%" 
		AND upper(evt.event_title) like "%XTANDI%" 
		AND UPPER(evt.event_title) LIKE "%OVERVIEW%"
		AND UPPER(evt.event_title) LIKE "%HEALTHCARE TEAM%"
		THEN "NURSE" 
		
		WHEN upper(evt.event_title) like "%ROLE OF XTANDI%" 
		AND upper(evt.event_title) like "%RESULTS%" 
		AND UPPER(evt.event_title) LIKE "%PREVAIL TRIAL%"
		AND upper(evt.event_title) like "%METASTATIC CRPC%" 
		THEN "PHYSICIAN" 
		
		WHEN upper(evt.event_title) LIKE "%XSS%"
		OR upper(evt.event_title) LIKE "REIMB"
		THEN "REIMBURSEMENT"
		
		WHEN upper(evt.event_title) LIKE "%XTANDI BROADCAST%"
		THEN "PHYSICIAN"
		
		WHEN UPPER(TRIM(evt.event_budget_name)) LIKE "%GPO%"
		THEN "GPO"

		WHEN UPPER(TRIM(evt.event_budget_name)) LIKE "%REIM%"
		THEN "REIMBURSEMENT"
		
		ELSE "UNKNOWN" END                                                      AS onc_prog_type			
			
	FROM sa_work.spkr_prgm_event_final evt
	WHERE UPPER(evt.PRODUCT) LIKE "%XTANDI%";

