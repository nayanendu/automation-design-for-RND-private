
#!/bin/bash

offset=43
folder_date=201802
script_loaded_date=2018-03-16
d1=$(date +"%Y-%m-%d")
add_offset=$(($(($(date -d $d1 "+%s") - $(date -d $script_loaded_date "+%s"))) / 86400))
offset=$((offset + add_offset))
load_date=$(date -d' -'$offset' days' +"%Y-%m-%d")\T10:00:00-04

source=flatiron_201802

 

entity=medication_order

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/MedicationOrder*

jobid1=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=medication_administration

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/MedicationAdministration*

jobid2=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=diagnosis

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Diag*

jobid3=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=enhanced_adv_gebiomakers

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Enhanced_AdvGEB*

jobid4=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=vitals

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Vitals.txt

jobid5=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=insurance

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Insurance*

jobid6=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=enhanced_mortality

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Enhanced_Mortality_V2.txt

jobid7=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=line_of_therapy

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Line*

jobid8=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=enhanced_adv_gesurgery

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Enhanced_AdvGES*

jobid9=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=demographics

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Demographics*

jobid10=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=enhanced_adv_gastricesoph

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Enhanced_AdvGas*

jobid11=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=ecog

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/ECOG*

jobid12=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=enhancedcohort

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/EnhancedC*

jobid13=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=visit

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Visit*

jobid14=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 

entity=lab

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /flatiron/$folder_date/Lab.txt

jobid15=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)



 


array=( $jobid1 $jobid2 $jobid3 $jobid4 $jobid5 $jobid6 $jobid7 $jobid8 $jobid9 $jobid10 $jobid11 $jobid12 $jobid13 $jobid14 $jobid15)


for i in ${array[@]}
   do
   echo $i_START
        status='RUNNING'
        while [ $status = 'RUNNING' ]
          do
            status=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient  GetLoadLogs podium ""#0{DKKG1+KPWIEhXrKIgW0igw==}"" http://10.208.2.65:8675/podium $i)
            sleep 2
            echo $status
          done
   echo $i_END
done

 
