
#!/bin/bash

offset=145
folder_date=20171101
script_loaded_date=2018-03-26
d1=$(date +"%Y-%m-%d")
add_offset=$(($(($(date -d $d1 "+%s") - $(date -d $script_loaded_date "+%s"))) / 86400))
offset=$((offset + add_offset))
load_date=$(date -d' -'$offset' days' +"%Y-%m-%d")\T10:00:00-04

source=ims_oncology_emr

 

entity=emr_client_panel

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_CLIENT_PANEL*

jobid1=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_facility

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_FACILITY*

jobid2=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_icd

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_ICD*

jobid3=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_observation_result

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR_OBSERVATION_RESULT.txt

jobid4=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_patient_diagnosis

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_PATIENT_DIAGNOSIS_Mth*

jobid5=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_patient_master_old

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_PATIENT_MASTER_Mth*

jobid6=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_performance_status

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_PERFORMANCE_STATUS*

jobid7=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_stage_history

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_STAGE_HISTORY*

jobid8=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_visit

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_VISIT_Mth*

jobid9=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_visit_drug_admin

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_VISIT_DRUG_ADMIN*

jobid10=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_visit_rx_ordered

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_VISIT_RX_ORDERED*

jobid11=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_patient

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR-ONC_PATIENT_Mth*

jobid12=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_patient_master_old_v1

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR_PATIENT_MASTER*

jobid13=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 

entity=emr_patient_master

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /06_EMR-ONC/$folder_date/EMR_PATIENT_MASTER*

jobid14=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 30s

 


array=( $jobid1 $jobid2 $jobid3 $jobid4 $jobid5 $jobid6 $jobid7 $jobid8 $jobid9 $jobid10 $jobid11 $jobid12 $jobid13 $jobid14)


for i in ${array[@]}
   do
   echo $i_START
        status='RUNNING'
        while [ $status = 'RUNNING' ]
          do
            status=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient  GetLoadLogs podium ""#0{DKKG1+KPWIEhXrKIgW0igw==}"" http://10.208.2.65:8675/podium $i)
            sleep 2
            echo $status
          done
   echo $i_END
done

 
