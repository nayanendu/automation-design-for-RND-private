
#!/bin/bash

offset=117
folder_date=201712
script_loaded_date=2018-03-28
d1=$(date +"%Y-%m-%d")
add_offset=$(($(($(date -d $d1 "+%s") - $(date -d $script_loaded_date "+%s"))) / 86400))
offset=$((offset + add_offset))
load_date=$(date -d' -'$offset' days' +"%Y-%m-%d")\T10:00:00-04

source=ims_ambulatory_emr

 

entity=px_lookup

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*pr_lookup*

jobid1=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=patients

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*patient*

jobid2=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=rx_lookup

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*rx_lookup*

jobid3=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=encounters

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*encount*

jobid4=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=manifest

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*MANIFEST*

jobid5=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=vitals

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*vital*

jobid6=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=results

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*results*

jobid7=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=dx_lookup

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*dx_lookup*

jobid8=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=allergy

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*allergy*

jobid9=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=providers

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*provider*

jobid10=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=medications

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*meds*

jobid11=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=problems

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*problem*

jobid12=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=vaccines

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*vaccine*

jobid13=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=orders

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /07_EMR-AMB/$folder_date/*orders*

jobid14=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 


array=( $jobid1 $jobid2 $jobid3 $jobid4 $jobid5 $jobid6 $jobid7 $jobid8 $jobid9 $jobid10 $jobid11 $jobid12 $jobid13 $jobid14)


for i in ${array[@]}
   do
   echo $i_START
        status='RUNNING'
        while [ $status = 'RUNNING' ]
          do
            status=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient  GetLoadLogs podium ""#0{DKKG1+KPWIEhXrKIgW0igw==}"" http://10.208.2.65:8675/podium $i)
            sleep 2
            echo $status
          done
   echo $i_END
done

 
