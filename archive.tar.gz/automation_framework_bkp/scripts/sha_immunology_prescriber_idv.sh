
#!/bin/bash

offset=13
folder_date=20180330
script_loaded_date=2018-04-12
d1=$(date +"%Y-%m-%d")
add_offset=$(($(($(date -d $d1 "+%s") - $(date -d $script_loaded_date "+%s"))) / 86400))
offset=$((offset + add_offset))
load_date=$(date -d' -'$offset' days' +"%Y-%m-%d")\T10:00:00-04

source=sha_immunology_prescriber_idv

 

entity=prescriber

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /sha_idv2/$folder_date/WEEKLY_PRESCRIBER_PAYER_DATA_IMM*.gz

jobid1=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=practitioner_reassign

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /sha_idv2/$folder_date/WK_WEEKLY_PRESCRIBER_REASSIGNMENT*.gz

jobid2=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=payer_product

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /sha_idv2/$folder_date/WEEKLY_PRESCRIBER_PAYER_PRODUCT_IMM*.gz

jobid3=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=practitioner

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /sha_idv2/$folder_date/WK_WEEKLY_PRESCRIBER_PAYER_DEMO*.gz

jobid4=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 


array=( $jobid1 $jobid2 $jobid3 $jobid4)


for i in ${array[@]}
   do
   echo $i_START
        status='RUNNING'
        while [ $status = 'RUNNING' ]
          do
            status=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient  GetLoadLogs podium ""#0{DKKG1+KPWIEhXrKIgW0igw==}"" http://10.208.2.65:8675/podium $i)
            sleep 2
            echo $status
          done
   echo $i_END
done

 
