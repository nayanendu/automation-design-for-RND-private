
#!/bin/bash

offset=0
folder_date=20180416
script_loaded_date=2018-04-16
d1=$(date +"%Y-%m-%d")
add_offset=$(($(($(date -d $d1 "+%s") - $(date -d $script_loaded_date "+%s"))) / 86400))
offset=$((offset + add_offset))
load_date=$(date -d' -'$offset' days' +"%Y-%m-%d")\T10:00:00-04

source=astellas_fusion

 

entity=call_clickstream

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CALL2_CLICKSTREAM*

jobid1=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=cycle_plan

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CYCLE_PLAN_2*

jobid2=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=call_key_message

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CALL2_KEY_MESSAGE*

jobid3=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=key_message

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_KEY_MESSAGE_*

jobid4=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=user_territory

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_USER_TERRITORY_*

jobid5=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=clm_presentation_slide

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CLM_PRESENTATION_SLIDE_*

jobid6=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=clm_presentation

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CLM_PRESENTATION_2*

jobid7=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_transaction

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_TRANSACTION*

jobid8=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=account_plan

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_ACCOUNT_PLAN*

jobid9=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=account_share

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_ACCOUNT_SHARE_2*

jobid10=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=contact

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CONTACT_*

jobid11=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=medical_event_intg_hist

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_MEDICAL_EVENT_INTG_HIST_*

jobid12=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=medical_evnt_config

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_MEDICAL_EVNT_CONFIG_*

jobid13=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=medical_evnt_notifi

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_MEDICAL_EVNT_NOTIFI_*

jobid14=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=product_metrics

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_PRODUCT_METRICS_*

jobid15=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=rep_roster

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_REP_ROSTER_*

jobid16=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_export_hist

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_EXPORT_HIST*

jobid17=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_inventory

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_INVENTORY_2*

jobid18=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_inventory_item

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_INVENTORY_ITEM*

jobid19=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_lot_share

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_LOT_SHARE*

jobid20=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=speaker

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SPEAKER_2*

jobid21=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=speaker_title

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SPEAKER_TITLE*

jobid22=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=tsf

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_TSF*

jobid23=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=user_role

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_USER_ROLE*

jobid24=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_lot

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_LOT_2*

jobid25=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_lot_add

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_LOT_ADD*

jobid26=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=call

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CALL2_2*

jobid27=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=call_discussion

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CALL2_DISCUSSION_*

jobid28=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=cycle_plan_detail

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CYCLE_PLAN_DETAIL_*

jobid29=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=cycle_plan_target

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CYCLE_PLAN_TARGET_*

jobid30=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sample_receipt

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SAMPLE_RECEIPT*

jobid31=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=qa_row_counts

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_CONTROL_*.txt.gz

jobid32=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_contract_partner

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_CONTRACT_PARTNER_*.*

jobid33=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_team_member

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_TEAM_MEMBER_*.*

jobid34=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_material

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_MATERIAL_*.*

jobid35=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_rule

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_RULE_*.*

jobid36=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_session

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_SESSION_*.*

jobid37=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_layout

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_LAYOUT_*.*

jobid38=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_action

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_ACTION_*.*

jobid39=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_contract

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_CONTRACT_2*.*

jobid40=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_budget

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_BUDGET_*.*

jobid41=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_astellas_settings

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_ASTELLAS_SETTINGS_*.*

jobid42=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_expense_type

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EXPENSE_TYPE_*.*

jobid43=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_contract_line

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_CONTRACT_LINE_*.*

jobid44=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_catalog

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_CATALOG_*.*

jobid45=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_budget

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_BUDGET_*.*

jobid46=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=record_type

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_RECORDTYPE_*

jobid47=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_expense_estimate_settings

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_ASTELLAS_EXPENSE_ESTIMATE_SETTINGS_*.*

jobid48=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=account

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_ACCOUNT_2*

jobid49=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=address

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_ADDRESS_2*

jobid50=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=call_details

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CALL2_DETAILS*

jobid51=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=medical_inquiry

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_MEDICAL_INQUIRY_*

jobid52=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=product

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_PRODUCT_2*

jobid53=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=territory

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_TERRITORY_2*

jobid54=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=user

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_USER_2*

jobid55=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=call_sample

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_CALL2_SAMPLE_*

jobid56=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=territory_hierarchy

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_TERRITORY_HIER_VW_*

jobid57=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=testTerritory

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas2/Fusion/$folder_date/FSN_DLZ_TERRITORY_HIER_VW_*

jobid58=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=territory_hierarchy_test

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas2/Fusion/$folder_date/FSN_DLZ_TERRITORY_HIER_VW_*

jobid59=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_venue

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_VENUE_*.*

jobid60=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=approved_emails

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_SENT_EMAIL_*.*

jobid61=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_expense_line

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EXPENSE_LINE_*.*

jobid62=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_expense_header

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EXPENSE_HEADER_*.*

jobid63=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event_speaker

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_SPEAKER_*.*

jobid64=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_speaker_qualification

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_SPEAKER_QUALIFICATION_*.*

jobid65=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_attendee

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_ATTENDEE_*.*

jobid66=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=repmail

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DTZ_MNG_REPMAIL_*

jobid67=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 

entity=sp_event

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob /Astellas3/Fusion/$folder_date/FSN_DLZ_EM_EVENT_2*.*

jobid68=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

 


array=( $jobid1 $jobid2 $jobid3 $jobid4 $jobid5 $jobid6 $jobid7 $jobid8 $jobid9 $jobid10 $jobid11 $jobid12 $jobid13 $jobid14 $jobid15 $jobid16 $jobid17 $jobid18 $jobid19 $jobid20 $jobid21 $jobid22 $jobid23 $jobid24 $jobid25 $jobid26 $jobid27 $jobid28 $jobid29 $jobid30 $jobid31 $jobid32 $jobid33 $jobid34 $jobid35 $jobid36 $jobid37 $jobid38 $jobid39 $jobid40 $jobid41 $jobid42 $jobid43 $jobid44 $jobid45 $jobid46 $jobid47 $jobid48 $jobid49 $jobid50 $jobid51 $jobid52 $jobid53 $jobid54 $jobid55 $jobid56 $jobid57 $jobid58 $jobid59 $jobid60 $jobid61 $jobid62 $jobid63 $jobid64 $jobid65 $jobid66 $jobid67 $jobid68)


for i in ${array[@]}
   do
   echo $i_START
        status='RUNNING'
        while [ $status = 'RUNNING' ]
          do
            status=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient  GetLoadLogs podium ""#0{DKKG1+KPWIEhXrKIgW0igw==}"" http://10.208.2.65:8675/podium $i)
            sleep 2
            echo $status
          done
   echo $i_END
done

 
