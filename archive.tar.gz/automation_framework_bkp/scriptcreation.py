#!/usr/bin/env python
__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
from mysqldatasource import *
from podiumutils import *
from dateutil.relativedelta import relativedelta

script_header = """
#!/bin/bash

offset=__offset
folder_date=__folder_date
script_loaded_date=__script_loaded_date
d1=$(date +"%Y-%m-%d")
add_offset=$(($(($(date -d $d1 "+%s") - $(date -d $script_loaded_date "+%s"))) / 86400))
offset=$((offset + add_offset))
load_date=$(date -d' -'$offset' days' +"%Y-%m-%d")\T10:00:00-04

source=__source

"""

script_body = """
entity=__entity

java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient SetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity src.file.glob __src.file.glob

__jobid=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient LoadData podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium $source $entity $load_date)

sleep 7s

"""

script_footer = """

array=(__array)


for i in ${array[@]}
   do
   echo $i_START
        status='RUNNING'
        while [ $status = 'RUNNING' ]
          do
            status=$(java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient  GetLoadLogs podium ""#0{DKKG1+KPWIEhXrKIgW0igw==}"" http://10.208.2.65:8675/podium $i)
            sleep 2
            echo $status
          done
   echo $i_END
done

"""

def offset_calculator(final_folder,folderformat,load_type):
        now = datetime.now()
        if load_type == 'quarterly':
		print "Inside quarterly"
                quarter = int(datetime.strptime(final_folder,'%s'%folderformat).month)
                offset_day = datetime.strptime(final_folder,'%s'%folderformat)
                two_mon_rel = relativedelta(months= int(quarter) * 2)
                offset_date = offset_day+two_mon_rel
                offset = (now - (offset_date+two_mon_rel)).days
        else:
		print "Inside normal"
                offset_date = datetime.strptime(final_folder,'%s'%folderformat)
                offset = (now - offset_date).days
        return offset_date,offset

def create_sh(sourcename,offset,folder_date,newsource = None):
	print "####################### Inside script creation"
	if '.' in sourcename:
		source=sourcename.split('.')[0]
		script_name=sourcename.replace('.','_')
	else:
		source,script_name=sourcename,sourcename
		
	os.system('rm -f scripts/%s.sh'%script_name)
	f = open( 'scripts/%s.sh'%script_name, 'a+' )
	if newsource == None:
		script_header_new = script_header.replace('__offset',str(offset)).replace('__folder_date',str(folder_date)).replace('__script_loaded_date',str(datetime.now().strftime('%Y-%m-%d'))).replace('__source',str(source))
	else:
		script_header_new = script_header.replace('__offset',str(offset)).replace('__folder_date',str(folder_date)).replace('__script_loaded_date',str(datetime.now().strftime('%Y-%m-%d'))).replace('__source',str(newsource))
	f.write('%s \n'%script_header_new)

	query = """SELECT entity_name,glob FROM entity WHERE source_id = (SELECT source_id FROM source WHERE source_name = '%s');"""%sourcename
	data = execute_fetch_data(query)
	
	job,arr=1,''
	for entites in data:
		jobid='jobid%s'%job
		script_body_new = script_body.replace('__entity',entites[0]).replace('__src.file.glob',entites[1]).replace('__jobid',str(jobid))
		f.write('%s \n'%script_body_new)
		arr = arr+' $%s'%jobid
		job = job+1
	script_footer_new = script_footer.replace('__array',arr)
	f.write('%s \n'%script_footer_new)
	f.close()

def create_sa_sh(sourcename):
	query = """SELECT a.source,a.sa_source,a.sa_entity,b.load_date_check,b.folder_format,b.load_type FROM subject_area a JOIN source b ON a.source=b.source_name and a.source='%s'"""%sourcename
        data = execute_fetch_data(query)
	
	for i in data:
		print i
		script_name=str(i[1])+'_'+str(i[2])
        	os.system('rm -f scripts/%s.sh'%script_name)
		offset_date,offset = offset_calculator(i[3],i[4],i[5])
        	f = open( 'scripts/%s.sh'%script_name, 'a+' )
        	script_header_new = script_header.replace('__offset',str(offset)).replace('__folder_date',str(i[3])).replace('__script_loaded_date',str(datetime.now().strftime('%Y-%m-%d'))).replace('__source',str(i[1]))
        	f.write('%s \n'%script_header_new)

		sa_sntity_details = fetch_source_entity_info(i[1],i[2])
        	job,arr=1,''
		jobid='jobid%s'%job
		print sa_sntity_details[0]
        	script_body_new = script_body.replace('__entity',str(sa_sntity_details[0][0])).replace('__src.file.glob',str(sa_sntity_details[0][2])).replace('__jobid',str(jobid))
        	f.write('%s \n'%script_body_new)
        	arr = arr+' $%s'%jobid
        	script_footer_new = script_footer.replace('__array',arr)
        	f.write('%s \n'%script_footer_new)
        	f.close()

