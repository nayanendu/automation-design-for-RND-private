__author__ = 'Nayanendu'


import os
import sys
from datetime import datetime,timedelta
import commands
import pexpect
from os.path import basename
from types import NoneType
from subprocess import Popen, PIPE
import shutil
import subprocess
import json
from mysqldatasource import *

def fetch_source_entity_info(sourceName,entityName = None):
	print "Inside fetch_source_entity_info",sourceName
	entity_info=list()
	os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
	cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/source/v1/getSourcesByCrit/?name='+sourceName+' --cookie cookies.txt'
	cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
	cmdJSON = json.load(cmdPipe.stdout)
	sid = cmdJSON[0]['id']
	print sid
	if entityName == None:
		cmd = """curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/%s --cookie cookies.txt"""%(sid)
		cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
		cmdJSON = json.load(cmdPipe.stdout)
		##print cmdJSON
		##sys.exit(1)
		for i in cmdJSON['subList']:
			print "#######################"
			if '_v1' not in i['name'] and '_v2' not in i['name']  and '_old' not in i['name']  and '_init' not in i['name']  and '_ugly' not in i['name'] :
				glob_pattern1=os.popen('java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient GetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium %s %s  src.file.glob'%(sourceName,i['name'])).read()
				glob_pattern=glob_pattern1[1:-2]
				temp = [i['name'],i['id'],glob_pattern]
				entity_info.append(temp)
	else:
		command2 = os.popen('curl -s --request GET http://10.208.2.65:8675/podium/entity/v1/byParentId/%s --cookie cookies.txt'%sid).read()
                sub_string = command2.split(entityName)[0]
                sub_string2 = sub_string[sub_string.rfind('id')+2:]
                eid = sub_string2[sub_string2.find(":")+1:sub_string2.find(",")].split()[0]
                glob_pattern1=os.popen('java -cp .:./PodiumAPIClient.jar com.podiumdata.tools.apiclient.PodiumAPIClient GetProp podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium '+sourceName+' '+entityName+' src.file.glob').read()
                glob_pattern=glob_pattern1[1:-2]
		temp = [entityName,eid,glob_pattern]
		entity_info.append(temp)
	return entity_info


def store_entities_to_db(source,source_id,oldsource=None):
	entity=None
	if '.' in source:
                act_source = source.split('.')[0]
                entity = source.split('.')[1]
	else:
		act_source = source
	query = """delete from entity where source_id=%s"""%source_id
	executequery(query)
	if oldsource == None:	
		entity_info = fetch_source_entity_info(act_source,entity)
	else:
		entity_info = fetch_source_entity_info(oldsource,entity)
	for i in entity_info : 
		val_to_replace = ''
		for j in i[2].split('/'):
			if '2016' in j or '2017' in j or '2018' in j :
				val_to_replace = j
		
		i[2] = i[2].replace('%s'%val_to_replace,'$folder_date')
		query = "insert into entity(source_name,entity_id,entity_name,source_id,glob) values('%s',%s,'%s',%s,'%s')"%(source,i[1],i[0],source_id,i[2])
		executequery(query)
	

def getLogs(source,load_date_check,folderformat,check_flag='ALL'):
	os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
	if check_flag == 'ALL':
		query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%source
	else:
		query = """SELECT group_conact(distinct entity_id) FROM detailed_logs WHERE source_name = '%s' and folderdate='%s';"""%(source,load_date_check)
        data = execute_fetch_data(query)
	data = data [0][0]
	entities = data.split(',')
        for entityID in entities:
		command='curl -s --request GET "http://10.208.2.65:8675/podium/entity/v1/loadLogs/'+entityID+'?count=1&sortAttr=loadTime" --cookie cookies.txt'
                logsPipe = Popen(command, shell=True, stdout=PIPE)
                logsJson = json.load(logsPipe.stdout)
                if len(load_date_check) < 6:
			load_date_check = datetime.strptime(load_date_check,'%s'%folderformat)
                        load_date_check = load_date_check.strftime('%s'%folderformat)
		##print "#################",len(logsJson['subList'])
		if len(logsJson['subList']) > 0 :
			if load_date_check in logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8]:
				if logsJson['subList'][0]['status'] == 'FAILED':
					executequery("""replace into detailed_logs(source_name,entity_name,deliverydate,status,info,folderdate) values('%s','%s','%s','FAILED','%s','%s')"""%(source,logsJson['subList'][0]['entityName'],logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8],logsJson['subList'][0]['infoMessage'].replace('\n',' ')[0:600],load_date_check))
				else:
					query = """insert ignore into detailed_logs(source_name,entity_name,deliverydate,status,info,folderdate,start_time,end_time,good_records,bad_records,ugly_records) values('%s','%s','%s','SUCCESS','DataLoaded','%s','%s','%s',%s,%s,%s)"""%(source,logsJson['subList'][0]['entityName'],logsJson['subList'][0]['deliveryId'].replace('<SOURCE_NAME>.<ENTITY_NAME>.','')[0:8],load_date_check,(datetime.fromtimestamp(logsJson['subList'][0]['startTime'] / 1e3)).strftime('%Y-%m-%d %H:%M:%S'),(datetime.fromtimestamp(logsJson['subList'][0]['endTime'] / 1e3)).strftime('%Y-%m-%d %H:%M:%S'),logsJson['subList'][0]['goodRecordCount'],logsJson['subList'][0]['badRecordCount'],logsJson['subList'][0]['uglyRecordCount'])
					executequery(query)
	return True

def updateZip(zipfname, oldSourceName, newSourceName):
    tempdir = tempfile.mkdtemp()
    try:
        tempname = os.path.join(tempdir, 'new.zip')
        with zipfile.ZipFile(zipfname, 'r') as zipread:
            with zipfile.ZipFile(tempname, 'w') as zipwrite:
                for item in zipread.infolist():
                        data = zipread.read(item.filename)
                        data1 = data.replace(oldSourceName, newSourceName)
                        zipwrite.writestr(item, data1)
        shutil.move(tempname, zipfname)
    finally:
        shutil.rmtree(tempdir)

def importExport(listOfSourceEntityWithIDs, oldSourceName, newSourceName, zipFileName):
        for sourceName in listOfSourceEntityWithIDs:
                        if oldSourceName in sourceName.split(':'):
                                sourceID = sourceName.split(':')[1].rstrip('\n')
        os.system("curl -s --request GET http://10.208.2.65:8675/podium/metadataExport/v1/sources/"+sourceID+" --cookie cookies.txt --output "+zipFileName)
        updateZip(zipFileName, oldSourceName, newSourceName)
        os.system('java -cp PodiumAPIClient.jar com.podiumdata.tools.apiclient.ImportEntity podium "#0{DKKG1+KPWIEhXrKIgW0igw==}" http://10.208.2.65:8675/podium '+zipFileName+">/dev/null 2>&1")




def get_qc_status(sourceName,source_extra=None):
	os.system("curl -d j_username=podium -d j_password=Welcome@123 -L http://10.208.2.65:8675/podium/j_spring_security_check --cookie-jar cookies.txt >/dev/null 2>&1")
	query = """select count(1) from qc_logs where source_name='%s'"""%sourceName
	data = execute_fetch_data(query)
	qc_cnt = data[0][0]

	if qc_cnt > 0 :
		query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%sourceName
		data = execute_fetch_data(query)
		data = data[0][0]
		entities = data.split(',')
		for entityID in entities:
			failed_col = 0
			eid = int(entityID) + 1
			cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
			cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
			cmdJSON = json.load(cmdPipe.stdout)
			for col_prop in cmdJSON['subList']:
				col_name = col_prop['name']
				if ('dt' in col_name or '_date' in col_name or 'id' in col_name) and 'podium_delivery_date' not in col_name:
					query = """select min,max from qc_logs where source_name='%s' and entity_id=%s and column_name='%s'"""%(sourceName,entityID,col_name)
					data = execute_fetch_data(query)
					print data
					data = data[0]
					print data
					pre_min,pre_max = data[0],data[1]
					cur_min,cur_max = col_prop['minValue'],col_prop['maxValue']
					if pre_min == 'None' and pre_max == 'None': 
						pass
					else:	
						if len(cur_min) == len(pre_min) and len(cur_max) == len(pre_max):
							print "Matching"
						else:
							failed_col = failed_col + 1
				entity_name = col_prop['parentEntityName']
			print entity_name
			if failed_col > 0 :
				update_query = """update detailed_logs set qc_status='FA' where source_name='%s' and entity_name='%s'"""%(sourceName,entity_name)
			else:
				update_query = """update detailed_logs set qc_status='SA' where source_name='%s' and entity_name='%s'"""%(sourceName,entity_name)
			executequery(update_query)
					
	else:
		query = """SELECT group_concat(entity_id) FROM entity WHERE source_name = '%s';"""%sourceName
                data = execute_fetch_data(query)
		data = data[0][0]
		print data
                entities = data.split(',')
                for entityID in entities:
                        eid = int(entityID) + 1
                        cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                        cmdPipe = Popen(cmd, shell=True, stdout=PIPE)
		        cmdJSON = json.load(cmdPipe.stdout)
                        for col_prop in cmdJSON['subList']:
                                col_name = col_prop['name']
                                if ('dt' in col_name or '_date' in col_name or 'id' in col_name) and 'podium_delivery_date' not in col_name:
					cur_min,cur_max = col_prop['minValue'],col_prop['maxValue']
					insert_query = """replace into qc_logs(source_name,entity_id,column_name,min,max) values('%s',%s,'%s','%s','%s')"""%(sourceName,entityID,col_name,cur_min,cur_max)
					executequery(insert_query)
                                        #cmd = 'curl -s --request GET http://10.208.2.65:8675/podium/field/v1/byEntityWithProfileSummary/%s --cookie cookies.txt'%eid
                                        #cmdP = Popen(cmd, shell=True, stdout=PIPE)
					#cmdJ = json.load(cmdP.stdout)
					#print cmdJ
					#sys.exit(1)
	return True				

        


##get_qc_status('astellas_customer_master')

##store_entities_to_db('ims_urology_emr',32)
##store_entities_to_db('astellas_customer_master',98)

##getLogs('astellas_customer_master','20171015','%Y%m%d')
		
